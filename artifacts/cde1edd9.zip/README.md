"""

"""

"""

# Chat Bot

A simple chatbot built with LangChain.

## Setup

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Set your OpenAI API key as an environment variable:
   ```bash
   export OPENAI_API_KEY="your-api-key-here"
   ```

3. (Optional) Configure model parameters via environment variables:
   - `OPENAI_MODEL_NAME` (default: `gpt-3.5-turbo`)
   - `OPENAI_TEMPERATURE` (default: `0.7`)
   - `OPENAI_MAX_TOKENS` (default: `1024`)

## Usage

```python
from chat_bot import ChatBot
from langchain_config import LangChainConfig

# Use default config (reads from environment)
bot = ChatBot()

# Or provide custom config
config = LangChainConfig(
    openai_api_key="your-api-key",
    model_name="gpt-4",
    temperature=0.5
)
bot = ChatBot(config)

# Send a message
response = bot.send_message("Hello!")
print(response)

# Get conversation history
history = bot.get_conversation_history()
print(history)
```

## Running Tests

```bash
pytest
```
