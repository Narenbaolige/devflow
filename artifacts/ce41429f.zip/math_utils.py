"""Math utility functions with input validation."""

import math


def factorial(n):
    """Compute the factorial of a non-negative integer.

    Args:
        n: An int or float representing the number to compute factorial for.

    Returns:
        int: The factorial of n.

    Raises:
        TypeError: If n is not an int or float.
        ValueError: If n is negative.
    """
    if not isinstance(n, (int, float)):
        raise TypeError(f"Expected int or float, got {type(n).__name__}")

    if isinstance(n, float):
        if n != math.floor(n):
            n = math.floor(n)
        n = int(n)

    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers")

    result = 1
    for i in range(2, n + 1):
        result *= i
    return result
