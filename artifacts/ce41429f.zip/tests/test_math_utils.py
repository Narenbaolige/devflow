"""Tests for math_utils.factorial with type validation."""

import math
import pytest
from math_utils import factorial


class TestFactorial:
    """Test suite for factorial function."""

    # --- Valid inputs ---

    @pytest.mark.parametrize("n,expected", [
        (0, 1),
        (1, 1),
        (2, 2),
        (3, 6),
        (5, 120),
        (10, 3628800),
    ])
    def test_factorial_with_integers(self, n, expected):
        """Factorial should correctly compute for non-negative integers."""
        assert factorial(n) == expected

    @pytest.mark.parametrize("n,expected", [
        (0.0, 1),
        (1.0, 1),
        (5.0, 120),
        (10.0, 3628800),
    ])
    def test_factorial_with_integer_floats(self, n, expected):
        """Factorial should handle floats that represent whole numbers."""
        assert factorial(n) == expected

    @pytest.mark.parametrize("n,expected", [
        (5.7, 120),   # floor(5.7) = 5 → 5! = 120
        (3.14, 6),    # floor(3.14) = 3 → 3! = 6
        (2.99, 2),    # floor(2.99) = 2 → 2! = 2
    ])
    def test_factorial_with_non_integer_floats(self, n, expected):
        """Factorial should floor non-integer floats before computing."""
        assert factorial(n) == expected

    # --- Invalid inputs: TypeError ---

    @pytest.mark.parametrize("invalid_input", [
        "5",
        [5],
        None,
        complex(1, 2),
        {"value": 5},
        (5,),
    ])
    def test_factorial_raises_type_error_for_non_numeric(self, invalid_input):
        """Factorial should raise TypeError for non-int/float inputs."""
        with pytest.raises(TypeError):
            factorial(invalid_input)

    # --- Invalid inputs: ValueError ---

    @pytest.mark.parametrize("negative_input", [
        -1,
        -5,
        -0.5,
        -100,
    ])
    def test_factorial_raises_value_error_for_negative(self, negative_input):
        """Factorial should raise ValueError for negative inputs."""
        with pytest.raises(ValueError):
            factorial(negative_input)
