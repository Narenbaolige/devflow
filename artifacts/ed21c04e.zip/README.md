"""

"""

# DevFlow Test Repository

A test repository for practicing DevFlow workflows. This project contains various Python modules demonstrating common patterns and intentional bugs for testing.

## Modules

- **calculator.py**: Simple calculator with add, subtract, multiply, divide operations.
- **config_loader.py**: JSON configuration file loader with default support.
- **constants.py**: Application constants (page size, API version).
- **data_pipeline.py**: Data pipeline with extract, transform, load stages.
- **file_handler.py**: File read/write/process utilities.
- **item_processor.py**: Item processing functions (double items, get first).
- **math_utils.py**: Mathematical utilities (factorial, fibonacci).
- **models.py**: User model (simple dataclass).
- **routes.py**: API route builder with pagination.
- **search.py**: Binary and linear search algorithms.
- **src/bubble_sort.py**: Bubble sort implementation.
- **user_service.py**: User management service with create/update.
- **utils.py**: Utility functions (calculate_values, format_result).
- **validators.py**: Validators module (currently empty).

## Installation

Clone the repository:

```bash
git clone https://github.com/Narenbaolige/devflow-test-repo.git
cd devflow-test-repo
```

No external dependencies are required. The project uses Python's standard library.

## Running Tests

Run all tests with pytest:

```bash
pytest
```

Run tests with verbose output:

```bash
pytest -v
```

Run tests for a specific module:

```bash
pytest test_calculator.py
pytest tests/test_bubble_sort.py
```

## Test Coverage

Tests cover the following modules:

- **calculator**: Basic arithmetic operations and edge cases (division by zero).
- **config_loader**: JSON parsing and default configuration loading.
- **data_pipeline**: Extract, transform, load stages and pipeline execution.
- **file_handler**: File read/write roundtrip, Unicode filenames, empty files, processing.
- **item_processor**: Normal list, empty list, single item processing; get first item.
- **math_utils**: Factorial (including negative input validation), Fibonacci sequence.
- **routes**: Pagination URL building with default and max size.
- **search**: Binary search (first, last, middle, not found, empty, single element) and linear search.
- **bubble_sort**: Basic sorting, already sorted, reverse, empty, single, duplicates, negative, type error.
- **user_service**: User creation (valid, short username, invalid email, negative age), update (email, nonexistent).
- **utils**: calculate_values (sum, product, key name), format_result.
- **models**: User creation and string representation.

Note: Some tests may fail due to intentional bugs in the source code (e.g., missing input validation, off-by-one errors, typos). These are left as exercises.