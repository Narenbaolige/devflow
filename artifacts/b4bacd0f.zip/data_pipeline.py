"""Data pipeline for DevFlow testing. Task-018: refactor the run() method."""


class DataPipeline:
    def __init__(self, source: list):
        self.source = source
        self.extracted: list = []
        self.transformed: list = []
        self.loaded: list = []

    def extract(self):
        """Extract data from source."""
        self.extracted = [x for x in self.source if x is not None]

    def transform(self):
        """Transform extracted data."""
        self.transformed = [x * 2 for x in self.extracted]

    def load(self):
        """Load transformed data."""
        self.loaded = list(self.transformed)

    def run(self):
        """Run the full pipeline by delegating to extract, transform, and load."""
        self.extract()
        self.transform()
        self.load()
        print(f"Pipeline complete: {len(self.loaded)} items loaded")
        return self.loaded
