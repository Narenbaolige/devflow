"""Simple calculator for DevFlow testing."""


class Calculator:
    """A simple calculator."""

    def add(self, a, b):
        return a + b

    def subtract(self, a, b):
        return a - b

    def multiply(self, a, b):
        return a * b

    def divide(self, a, b):
        if b == 0:
            return None
        return a / b

    def power(self, base, exp):
        """Calculate base raised to the power of exp."""
        return base ** exp
