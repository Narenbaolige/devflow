from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort

from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort

from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort

from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort
from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort
from utils.math_utils import factorial
from utils.math_utils import fibonacci

# DevFlow Test Repo

## Project Overview

This repository is a demonstration project for testing the DevFlow agent system. It contains a variety of simple Python modules, web games, and services that showcase code generation, testing, and documentation capabilities.

## Directory Structure

```
.
├── README.md               # Project documentation
├── requirements.txt        # Python dependencies
├── api/                    # API routes and tests
│   ├── __init__.py
│   ├── routes.py
│   └── test_routes.py
├── chatbot/                # LangChain-based chatbot
│   ├── __init__.py
│   ├── chat_bot.py
│   └── langchain_config.py
├── data_pipeline/          # Data pipeline modules
│   ├── __init__.py
│   ├── config_loader.py
│   ├── data_pipeline.py
│   ├── file_handler.py
│   ├── item_processor.py
│   ├── test_config_loader.py
│   ├── test_data_pipeline.py
│   ├── test_file_handler.py
│   └── test_item_processor.py
├── games/                  # Games (2048, calculator, gomoku)
│   ├── __init__.py
│   ├── 2048/
│   │   ├── index.html
│   │   ├── script.js
│   │   └── style.css
│   ├── calculator.py
│   ├── gomoku.py
│   ├── test_calculator.py
│   └── test_gomoku.py
├── services/               # User service and models
│   ├── __init__.py
│   ├── models.py
│   ├── user_service.py
│   ├── test_user.py
│   └── test_user_service.py
├── sorting/                # Sorting algorithms
│   ├── __init__.py
│   ├── sorting.py
│   └── test_sorting.py
├── src/                    # Additional source code
│   └── bubble_sort.py
├── tests/                  # Additional tests
│   └── test_bubble_sort.py
└── utils/                  # Utility modules
    ├── __init__.py
    ├── constants.py
    ├── math_utils.py
    ├── search.py
    ├── utils.py
    ├── validators.py
    ├── test_math_utils.py
    ├── test_search.py
    └── test_utils.py
```

## Module Descriptions

### api
- `routes.py`: API route utilities, including pagination URL builder.
- `test_routes.py`: Tests for API routes.

### chatbot
- `chat_bot.py`: A chatbot using LangChain with conversation memory.
- `langchain_config.py`: Configuration dataclass for the chatbot (API key, model, temperature, etc.).

### data_pipeline
- `config_loader.py`: Load JSON configuration files with defaults.
- `data_pipeline.py`: A simple ETL pipeline (extract, transform, load).
- `file_handler.py`: Read/write/process files.
- `item_processor.py`: Process items (double values) and get first item.
- `test_*.py`: Unit tests for each module.

### games
- `2048/`: A 2048 game implemented in HTML, CSS, and JavaScript.
- `calculator.py`: A simple calculator (add, subtract, multiply, divide, power).
- `gomoku.py`: A 15x15 Gomoku (five-in-a-row) game board.
- `test_calculator.py`, `test_gomoku.py`: Tests for calculator and gomoku.

### services
- `models.py`: User model (dataclass with name and email).
- `user_service.py`: User service with create/update operations and validation.
- `test_user.py`, `test_user_service.py`: Tests for user model and service.

### sorting
- `sorting.py`: Selection sort implementation.
- `test_sorting.py`: Tests for selection sort.

### src
- `bubble_sort.py`: Bubble sort implementation.

### utils
- `constants.py`: Application constants (page size, API version).
- `math_utils.py`: Math utilities (factorial, fibonacci).
- `search.py`: Search algorithms (binary search, linear search).
- `utils.py`: General utilities (calculate_values, format_result, bubble_sort).
- `validators.py`: Placeholder for validation logic.
- `test_*.py`: Unit tests for each utility module.

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/Narenbaolige/devflow-test-repo.git
   cd devflow-test-repo
   ```

2. (Optional) Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

### Running Tests

Run all tests with pytest:
```bash
pytest
```

### Using Modules

```python
from utils.math_utils import factorial, fibonacci
from utils.search import binary_search
from sorting.sorting import selection_sort
from games.calculator import Calculator

# Example: factorial
print(factorial(5))  # 120

# Example: binary search
arr = [1, 3, 5, 7, 9]
index = binary_search(arr, 5)
print(index)  # 2

# Example: selection sort
sorted_list = selection_sort([3, 1, 4, 1, 5])
print(sorted_list)  # [1, 1, 3, 4, 5]

# Example: calculator
calc = Calculator()
print(calc.add(2, 3))  # 5
```

### Playing 2048

Open `games/2048/index.html` in a web browser.

## Contributing

1. Fork the repository.
2. Create a feature branch (`git checkout -b feature/my-feature`).
3. Make your changes and add tests.
4. Run `pytest` to ensure all tests pass.
5. Commit your changes (`git commit -am 'Add my feature'`).
6. Push to the branch (`git push origin feature/my-feature`).
7. Open a Pull Request.

Please ensure your code follows the existing style and includes appropriate tests.