import pytest
from math_utils import factorial, fibonacci


class TestFactorial:
    def test_factorial_zero(self):
        assert factorial(0) == 1

    def test_factorial_one(self):
        assert factorial(1) == 1

    def test_factorial_five(self):
        assert factorial(5) == 120

    def test_factorial_negative_should_raise(self):
        """This test expects ValueError — which the current code does NOT raise."""
        with pytest.raises(ValueError):
            factorial(-1)

    def test_factorial_non_integer_raises_typeerror(self):
        """Test that non-integer inputs raise TypeError."""
        with pytest.raises(TypeError, match="integer"):
            factorial('5')
        with pytest.raises(TypeError, match="integer"):
            factorial(5.0)


class TestFibonacci:
    def test_fib_zero(self):
        assert fibonacci(0) == 0

    def test_fib_one(self):
        assert fibonacci(1) == 1

    def test_fib_ten(self):
        assert fibonacci(10) == 55
