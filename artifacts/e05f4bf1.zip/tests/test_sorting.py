import pytest
from sorting import selection_sort


def test_empty_list():
    """输入空列表时返回空列表"""
    assert selection_sort([]) == []


def test_sorted_list():
    """输入已排序列表时返回相同列表"""
    assert selection_sort([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]


def test_unsorted_list():
    """输入乱序列表时返回升序排列的列表"""
    assert selection_sort([3, 1, 4, 1, 5, 9, 2, 6]) == [1, 1, 2, 3, 4, 5, 6, 9]


def test_duplicates():
    """输入包含重复元素的列表时正确排序"""
    assert selection_sort([5, 3, 5, 2, 3]) == [2, 3, 3, 5, 5]


def test_original_list_unchanged():
    """函数不修改原始输入列表"""
    original = [3, 1, 2]
    copy = original[:]
    result = selection_sort(original)
    assert original == copy
