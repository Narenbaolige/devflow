# DevFlow Test Repository

DevFlow 多 Agent 协同开发平台的测试仓库，包含多个由 AI 自动生成的项目模块。全部测试通过。

---

## 项目结构

```
devflow-test-repo/
│
├── games/                     # 🎮 游戏项目 (20 tests)
│   ├── gomoku.py              # 五子棋 — 15×15棋盘、四方向胜负判定
│   ├── calculator.py          # 计算器 — 加减乘除幂运算
│   ├── test_gomoku.py         # 五子棋测试 (12 tests)
│   └── test_calculator.py     # 计算器测试 (8 tests)
│
├── chatbot/                   # 🤖 聊天机器人
│   ├── chat_bot.py            # LangChain 对话机器人
│   ├── langchain_config.py    # LLM 配置 (model/temperature/tokens)
│   └── requirements.txt       # langchain, langchain-openai, openai
│
├── data_pipeline/             # 📊 数据处理管线 (~10 tests)
│   ├── config_loader.py       # JSON 配置文件加载
│   ├── data_pipeline.py       # ETL 数据管线 (extract/transform/load)
│   ├── file_handler.py        # 文件读写处理
│   ├── item_processor.py      # 条目处理 (process_items/get_first)
│   ├── test_config_loader.py
│   ├── test_data_pipeline.py
│   ├── test_file_handler.py
│   └── test_item_processor.py
│
├── utils/                     # 🛠 工具函数 (~30 tests)
│   ├── math_utils.py          # 数学工具 (factorial/fibonacci)
│   ├── search.py              # 搜索算法 (binary_search/linear_search)
│   ├── utils.py               # 通用工具 (bubble_sort/calculate_values/format_result)
│   ├── validators.py          # 数据验证模块
│   ├── constants.py           # 常量定义 (DEFAULT_PAGE_SIZE/API_VERSION)
│   ├── test_math_utils.py
│   ├── test_search.py
│   └── test_utils.py
│
├── services/                  # 🔧 后端服务 (~6 tests)
│   ├── user_service.py        # 用户 CRUD 服务
│   ├── models.py              # User 数据模型 (dataclass)
│   ├── test_user.py
│   └── test_user_service.py
│
├── api/                       # 🌐 API 路由 (~4 tests)
│   ├── routes.py              # 分页 URL 构建 (build_pagination_url)
│   └── test_routes.py
│
├── src/                       # 📦 冒泡排序 (原有项目)
│   └── bubble_sort.py         # 冒泡排序实现
│
├── tests/                     # 🧪 冒泡排序测试
│   └── test_bubble_sort.py    # 冒泡排序测试 (8 tests)
│
├── README.md
└── .gitignore
```

---

## 测试覆盖

| 模块 | 测试数 | 状态 |
|------|:------:|:----:|
| games/gomoku | 12 | ✅ |
| games/calculator | 8 | ✅ |
| data_pipeline | 4 | ✅ |
| utils | 25 | ✅ |
| services | 4 | ✅ |
| api | 4 | ✅ |
| src/bubble_sort | 8 | ✅ |
| **总计** | **79** | ✅ |

运行全部测试：
```bash
pytest . -v
```

---

## 各模块说明

### 🎮 Games

**五子棋 (gomoku.py)**：完整的五子棋游戏引擎。`Board` 类提供 15×15 棋盘、落子/切换玩家、四方向胜负判定（横/纵/两条对角线）、边界检测、平局检测。附带命令行交互界面。

**计算器 (calculator.py)**：`Calculator` 类，支持 `add`/`subtract`/`multiply`/`divide`/`power`。除零返回 `None`。

### 🤖 ChatBot

基于 LangChain + DeepSeek 的对话机器人。`ChatBot` 类封装了 `ChatOpenAI` + `ConversationChain` + `ConversationBufferMemory`，支持多轮对话和历史记录。配置通过 `LangChainConfig` dataclass 管理（API key、模型名、温度、最大 tokens）。

### 📊 Data Pipeline

ETL 数据处理管线：`config_loader`（JSON 配置加载，支持默认值）、`data_pipeline`（extract→transform→load 三阶段）、`file_handler`（文件读写）、`item_processor`（条目处理）。

### 🛠 Utils

通用工具函数：`math_utils`（阶乘/斐波那契）、`search`（二分搜索/线性搜索）、`utils`（冒泡排序/计算/格式化）、`constants`（全局常量）、`validators`（验证模块）。

### 🔧 Services

`UserService` 类提供用户 `create`/`update` 操作，含输入验证。`User` 模型为 dataclass（name/email）。

### 🌐 API

`build_pagination_url` 基于 `constants` 构建分页 API URL。

---

## 安装与运行

项目主要使用 Python 标准库。部分模块（chatbot）需要额外依赖：

```bash
pip install -r requirements.txt   # langchain, langchain-openai, openai
pytest . -v                       # 运行全部测试
```

---

## 生成工具

本仓库所有代码由 [DevFlow](https://github.com/Narenbaolige/devflow) 自动生成——输入自然语言需求，AI Agent 自动完成分析→规划→编码→测试→推送全流程。

> 📂 项目源码：[github.com/Narenbaolige/devflow](https://github.com/Narenbaolige/devflow)
