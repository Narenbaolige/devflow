# Chatbot

A modular chatbot framework built with Python, leveraging large language models (LLMs) for conversational AI. Supports configurable chat chains and memory management.

## Features

- Multi-turn conversational capabilities
- Extensible chat chain pipeline
- Persistent memory storage for context
- Easy configuration via environment or config file

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/randomandsafe-dev/test.git
   cd test
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

### Basic Chatbot

```python
from chatbot import Chatbot

bot = Chatbot()
response = bot.chat("Hello, how are you?")
print(response)
```

### Using a Custom Chat Chain

```python
from chat_chain import SimpleChain
from memory import Memory

chain = SimpleChain()
memory = Memory()

memory.add("user", "Hello")
output = chain.run("Hello", memory.get_history())
print(output)
```

## Configuration

Copy `config.py` and adjust settings as needed, or set environment variables. Supported options include:

- `LLM_MODEL`: model name/path
- `TEMPERATURE`: generation temperature
- `MAX_TOKENS`: maximum response length

## API Reference

### Chatbot

- `chat(message: str) -> str`: process a user message and return bot reply.
- `reset()`: clear conversation history.

### ChatChain

- `run(input_text: str, context: List[str]) -> str`: execute the chain with given input and context.

### Memory

- `add(role: str, content: str)`: store a message.
