from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort

from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort

from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort

from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort
from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort
from utils.math_utils import factorial
from utils.math_utils import fibonacci

# DevFlow Test Repo

## 项目简介

这是一个用于测试 DevFlow 工作流的示例仓库。仓库包含多个简单的 Python 模块，用于演示代码分析、测试和文档生成等功能。

## 目录结构

```
.
├── README.md               # 项目说明文档（本文件）
├── math_utils.py           # 数学工具函数（阶乘、斐波那契等）
├── string_utils.py         # 字符串处理工具（反转、大写等）
├── test_math_utils.py      # 数学工具函数的单元测试
├── test_string_utils.py    # 字符串处理函数的单元测试
└── requirements.txt        # 项目依赖（如有）
```

## 功能模块

### math_utils.py
- `factorial(n)` - 计算 n 的阶乘
- `fibonacci(n)` - 生成前 n 个斐波那契数列
- `is_prime(n)` - 判断 n 是否为质数

### string_utils.py
- `reverse_string(s)` - 反转字符串
- `to_uppercase(s)` - 将字符串转换为大写
- `is_palindrome(s)` - 判断字符串是否为回文

## 使用说明

1. 克隆仓库：`git clone <repo-url>`
2. 运行测试：`pytest`
3. 导入模块：`from math_utils import factorial`

## 许可证

本项目仅供测试使用。