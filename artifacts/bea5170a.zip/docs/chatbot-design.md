# Chatbot Project Design

## Current Repository Structure
- main.py: simple Python script that prints 'Hello, World!'.
- No package.json, requirements.txt, or other framework indicators.
