"""
Simple CLI chatbot with basic echo and quit functionality.
"""

import sys


def process_message(message: str) -> str:
    """Process user message and return a response.

    Currently implements simple echo. In the future, this can be extended
    to integrate NLP/LLM services.
    """
    if not message.strip():
        return "I didn't catch that. Could you say something?"
    return f"You said: {message}"


def main():
    """Run the chatbot in interactive CLI mode."""
    print("Chatbot: Hello! I am your assistant. Type 'quit' to exit.")
    while True:
        try:
            user_input = input("You: ")
        except (EOFError, KeyboardInterrupt):
            print("\nChatbot: Goodbye!")
            sys.exit(0)

        if user_input.lower() in ("quit", "exit", "bye"):
            print("Chatbot: Goodbye!")
