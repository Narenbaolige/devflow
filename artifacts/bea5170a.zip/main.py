print('Hello, World!')
