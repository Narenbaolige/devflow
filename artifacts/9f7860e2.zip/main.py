class Board:
    """15×15 棋盘，管理落子、判空和显示"""
    def __init__(self):
        self.size = 15
        self.grid = [[' ' for _ in range(self.size)] for _ in range(self.size)]

    def init_board(self):
        self.grid = [[' ' for _ in range(self.size)] for _ in range(self.size)]

    def place_stone(self, row, col, color):
        if not self.is_empty(row, col):
            return False
        self.grid[row][col] = color
        return True

    def is_empty(self, row, col):
        return self.grid[row][col] == ' '

    def display(self):
        print('  ' + ' '.join(str(i % 10) for i in range(self.size)))
        for i, row in enumerate(self.grid):
            print(str(i % 10) + ' ' + ' '.join(row))


class GomokuRules:
    """五子棋胜负判定"""
    def check_win(self, board, color):
        size = board.size
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        for r in range(size):
            for c in range(size):
                if board.grid[r][c] != color:
                    continue
                for dr, dc in directions:
                    count = 0
                    for step in range(5):
                        nr, nc = r + dr * step, c + dc * step
                        if 0 <= nr < size and 0 <= nc < size and board.grid[nr][nc] == color:
                            count += 1
                        else:
                            break
                    if count == 5:
                        return True
        return False

    def is_draw(self, board):
        for row in board.grid:
            if ' ' in row:
                return False
        return True


class PlayerInput:
    """用户输入处理与合法性校验"""
    def get_move(self, board, player_color):
        while True:
            try:
                inp = input(f'玩家 {player_color} 请输入坐标 (行,列): ')
                parts = inp.strip().split(',')
                if len(parts) != 2:
                    print('格式错误，请用逗号分隔行和列')
                    continue
                row, col = int(parts[0]), int(parts[1])
                if not (0 <= row < 15 and 0 <= col < 15):
                    print('坐标范围应为 0-14')
                    continue
                if not board.is_empty(row, col):
                    print('该位置已有棋子')
                    continue
                return row, col
            except ValueError:
                print('请输入数字')


class UIRenderer:
    """棋盘渲染与消息显示"""
    def render_board(self, board):
        board.display()

    def show_message(self, message):
        print(message)


