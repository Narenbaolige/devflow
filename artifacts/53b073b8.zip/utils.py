"""Utility functions for DevFlow testing."""


def calculate_values(a: int, b: int) -> dict:
    """Return calculated values. Contains an intentional typo."""
    return {
        "sum": a + b,
        "product": a * b,
        "calculated_value": a * b * 2,
    }


def format_result(data: dict) -> str:
    """Format a result dictionary as a string."""
    return ", ".join(f"{k}={v}" for k, v in data.items())


def bubble_sort(arr: list) -> list:
    """Sort a list using bubble sort algorithm. Returns a new sorted list without modifying the original."""
    if not arr:
        return []
    result = list(arr)
    n = len(result)
    for i in range(n):
        for j in range(0, n - i - 1):
            if result[j] > result[j + 1]:
                result[j], result[j + 1] = result[j + 1], result[j]
    return result
