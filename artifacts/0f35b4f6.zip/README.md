# 五子棋

## 目录

- [项目简介](#项目简介)
- [安装](#安装)
- [使用](#使用)
- [游戏规则](#游戏规则)
- [贡献](#贡献)
- [许可证](#许可证)

## 项目简介

这是一个基于 Python 的五子棋游戏，支持双人对战。玩家轮流在棋盘上落子，先连成五子者获胜。

## 安装

1. 确保已安装 Python 3.6 或更高版本。
2. 克隆本仓库：
   ```bash
   git clone https://github.com/Narenbaolige/devflow-test-repo.git
   ```
3. 进入项目目录：
   ```bash
   cd devflow-test-repo
   ```
4. （可选）创建虚拟环境：
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   venv\Scripts\activate  # Windows
   ```
5. 安装依赖：
   ```bash
   pip install -r requirements.txt
   ```

## 使用

运行游戏：
```bash
python gomoku.py
```

游戏启动后，会显示一个 15x15 的棋盘。玩家轮流输入坐标（例如 `7,7`）来落子。黑棋先行。

## 游戏规则

- 棋盘为 15x15 的网格。
- 两名玩家分别执黑棋和白棋。
- 黑棋先行，双方轮流在空位落子。
- 先在横、竖、斜任一方向上连成五子的一方获胜。
- 如果棋盘下满无人获胜，则为平局。

## 贡献

欢迎提交 Issue 或 Pull Request 来改进项目。

## 许可证

本项目采用 MIT 许可证。