def selection_sort(arr):
    """
    选择排序算法，返回排序后的新列表，不修改原列表。

    参数:
        arr: 输入列表

    返回:
        排序后的新列表
    """
    if not isinstance(arr, list):
        raise TypeError("Input must be a list")
    result = arr[:]
    n = len(result)
    for i in range(n):
        min_idx = i
        for j in range(i + 1, n):
            if result[j] < result[min_idx]:
                min_idx = j
        if min_idx != i:
            result[i], result[min_idx] = result[min_idx], result[i]
    return result
