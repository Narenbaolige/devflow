"""Tests for bubble_sort module."""


def test_bubble_sort_basic():
    from src.bubble_sort import bubble_sort
    assert bubble_sort([3, 1, 2]) == [1, 2, 3]


def test_bubble_sort_sorted():
    from src.bubble_sort import bubble_sort
    assert bubble_sort([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]


def test_bubble_sort_reverse():
    from src.bubble_sort import bubble_sort
    assert bubble_sort([5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5]


def test_bubble_sort_empty():
    from src.bubble_sort import bubble_sort
    assert bubble_sort([]) == []


def test_bubble_sort_single():
    from src.bubble_sort import bubble_sort
    assert bubble_sort([42]) == [42]


def test_bubble_sort_duplicates():
    from src.bubble_sort import bubble_sort
    assert bubble_sort([3, 3, 1, 1, 2, 2]) == [1, 1, 2, 2, 3, 3]


def test_bubble_sort_negative():
    from src.bubble_sort import bubble_sort
    assert bubble_sort([-3, 1, -5, 0, 2]) == [-5, -3, 0, 1, 2]


def test_bubble_sort_type_error():
    from src.bubble_sort import bubble_sort
    try:
        bubble_sort("not a list")
        assert False, "Should have raised TypeError"
    except TypeError:
        pass
