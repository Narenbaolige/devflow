from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort

from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort

from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort

# DevFlow Test Repo

A demonstration repository for testing DevFlow workflows. Contains multiple modules including API routes, a chatbot, data pipeline, games, services, sorting algorithms, and utility functions.

## Installation

1. Ensure Python 3.11 or higher is installed.
2. Clone the repository:
   ```bash
   git clone https://github.com/Narenbaolige/devflow-test-repo.git
   cd devflow-test-repo
   ```
3. (Optional) Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   venv\Scripts\activate  # Windows
   ```
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Project Structure

```
.
├── .gitignore
├── README.md
├── requirements.txt
├── api/
│   ├── __init__.py
│   ├── routes.py
│   └── test_routes.py
├── chatbot/
│   ├── __init__.py
│   ├── chat_bot.py
│   └── langchain_config.py
├── data_pipeline/
│   ├── __init__.py
│   ├── config_loader.py
│   ├── data_pipeline.py
│   ├── file_handler.py
│   ├── item_processor.py
│   ├── test_config_loader.py
│   ├── test_data_pipeline.py
│   ├── test_file_handler.py
│   └── test_item_processor.py
├── games/
│   ├── __init__.py
│   ├── calculator.py
│   ├── gomoku.py
│   ├── test_calculator.py
│   ├── test_gomoku.py
│   └── 2048/
│       ├── index.html
│       ├── script.js
│       └── style.css
├── services/
│   ├── __init__.py
│   ├── models.py
│   ├── test_user.py
│   ├── test_user_service.py
│   └── user_service.py
├── sorting/
│   ├── __init__.py
│   ├── sorting.py
│   └── test_sorting.py
├── src/
│   └── bubble_sort.py
├── tests/
│   └── test_bubble_sort.py
└── utils/
    ├── __init__.py
    ├── constants.py
    ├── math_utils.py
    ├── search.py
    ├── test_math_utils.py
    ├── test_search.py
    ├── test_utils.py
    ├── utils.py
    └── validators.py
```

## Modules

### API
- `api/routes.py`: Provides `build_pagination_url()` to construct paginated API URLs using constants from `utils/constants.py`.

### Chatbot
- `chatbot/chat_bot.py`: A LangChain-based chatbot with conversation memory. Uses `ChatOpenAI` and `ConversationChain`.
- `chatbot/langchain_config.py`: Configuration dataclass for the chatbot, reading environment variables.

### Data Pipeline
- `data_pipeline/config_loader.py`: Functions `parse_config()` and `load_config()` for reading JSON configuration files.
- `data_pipeline/data_pipeline.py`: `DataPipeline` class with extract, transform, load steps.
- `data_pipeline/file_handler.py`: Functions `read_file()`, `write_file()`, and `process_file()` for file I/O.
- `data_pipeline/item_processor.py`: Functions `process_items()` and `get_first()` for item processing.

### Games
- `games/calculator.py`: `Calculator` class with basic arithmetic operations (add, subtract, multiply, divide, power).
- `games/gomoku.py`: `Board` class for a 15x15 Gomoku (five-in-a-row) game.
- `games/2048/`: A browser-based 2048 game (HTML, CSS, JavaScript).

### Services
- `services/models.py`: `User` dataclass with name and email.
- `services/user_service.py`: `UserService` class for creating and updating users with validation.