import pytest
from games.calculator import Calculator


@pytest.fixture
def calc():
    return Calculator()


class TestCalculator:
    def test_add(self, calc):
        assert calc.add(2, 3) == 5

    def test_subtract(self, calc):
        assert calc.subtract(5, 3) == 2

    def test_multiply(self, calc):
        assert calc.multiply(2, 3) == 6

    def test_divide(self, calc):
        assert calc.divide(10, 2) == 5.0

    def test_divide_by_zero(self, calc):
        assert calc.divide(10, 0) is None

    def test_power(self, calc):
        assert calc.power(2, 3) == 8

    def test_power_zero(self, calc):
        assert calc.power(2, 0) == 1

    def test_power_negative(self, calc):
        assert calc.power(2, -1) == 0.5
