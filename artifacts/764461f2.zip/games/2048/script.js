const gridContainer = document.getElementById('grid-container');
const messageEl = document.getElementById('message');
const newGameBtn = document.getElementById('new-game-btn');

let grid = [];
let score = 0;
let gameOver = false;
let won = false;

function initGrid() {
    grid = Array.from({ length: 4 }, () => Array(4).fill(0));
    addRandomTile();
    addRandomTile();
    renderGrid();
    messageEl.style.display = 'none';
    gameOver = false;
    won = false;
}

function addRandomTile() {
    const emptyCells = [];
    for (let r = 0; r < 4; r++) {
        for (let c = 0; c < 4; c++) {
            if (grid[r][c] === 0) emptyCells.push({ r, c });
        }
    }
    if (emptyCells.length === 0) return;
    const { r, c } = emptyCells[Math.floor(Math.random() * emptyCells.length)];
    grid[r][c] = Math.random() < 0.9 ? 2 : 4;
}

function renderGrid() {
    gridContainer.innerHTML = '';
    for (let r = 0; r < 4; r++) {
        for (let c = 0; c < 4; c++) {
            const tile = document.createElement('div');
            tile.className = 'tile';
            const val = grid[r][c];
            tile.textContent = val !== 0 ? val : '';
            tile.style.background = getTileColor(val);
            tile.style.color = val > 4 ? '#f9f6f2' : '#776e65';
            gridContainer.appendChild(tile);
        }
    }
}

function getTileColor(val) {
    const colors = {
        0: '#cdc1b4',
        2: '#eee4da',
        4: '#ede0c8',
        8: '#f2b179',
        16: '#f59563',
        32: '#f67c5f',
        64: '#f65e3b',
        128: '#edcf72',
        256: '#edcc61',
        512: '#edc850',
        1024: '#edc53f',
        2048: '#edc22e'
    };
    return colors[val] || '#cdc1b4';
}

function move(direction) {
    if (gameOver || won) return;
    let moved = false;
    const newGrid = grid.map(row => [...row]);
    const addScore = (points) => { score += points; };

    const rotate = (matrix, times) => {
        let m = matrix.map(row => [...row]);
        for (let t = 0; t < times; t++) {
            const n = m.length;
            const rotated = Array.from({ length: n }, () => Array(n).fill(0));
            for (let i = 0; i < n; i++) {
                for (let j = 0; j < n; j++) {
                    rotated[j][n - 1 - i] = m[i][j];
                }
            }
            m = rotated;
        }
        return m;
    };

    const slide = (row) => {
        let arr = row.filter(v => v !== 0);
        let newRow = [];
        let i = 0;
        while (i < arr.length) {
            if (i + 1 < arr.length && arr[i] === arr[i + 1]) {
                newRow.push(arr[i] * 2);
                addScore(arr[i] * 2);
                i += 2;
            } else {
                newRow.push(arr[i]);
                i++;
            }
        }
        while (newRow.length < 4) newRow.push(0);
        return newRow;
    };

    let rotated;
    let rotations;
    switch (direction) {
        case 'left': rotations = 0; break;
        case 'up': rotations = 1; break;
        case 'right': rotations = 2; break;
        case 'down': rotations = 3; break;
        default: return;
    }

    rotated = rotate(newGrid, rotations);
    for (let r = 0; r < 4; r++) {
        const slid = slide(rotated[r]);
        if (slid.join(',') !== rotated[r].join(',')) moved = true;
        rotated[r] = slid;
    }
    const finalGrid = rotate(rotated, (4 - rotations) % 4);
    grid = finalGrid;

    if (moved) {
        addRandomTile();
        renderGrid();
        checkWin();
        if (!won) checkGameOver();
    }
}

function checkWin() {
    for (let r = 0; r < 4; r++) {
        for (let c = 0; c < 4; c++) {
            if (grid[r][c] === 2048) {
                won = true;
                messageEl.textContent = '挑战成功！';
                messageEl.style.display = 'flex';
                return;
            }
        }
    }
}

function checkGameOver() {
    for (let r = 0; r < 4; r++) {
        for (let c = 0; c < 4; c++) {
            if (grid[r][c] === 0) return;
            if (c < 3 && grid[r][c] === grid[r][c+1]) return;
            if (r < 3 && grid[r][c] === grid[r+1][c]) return;
        }
    }
    gameOver = true;
    messageEl.textContent = '游戏结束';
    messageEl.style.display = 'flex';
}

function handleKeydown(e) {
    const keyMap = {
        'ArrowUp': 'up',
        'ArrowDown': 'down',
        'ArrowLeft': 'left',
        'ArrowRight': 'right'
    };
    const dir = keyMap[e.key];
    if (dir) {
        e.preventDefault();
        move(dir);
    }
}

newGameBtn.addEventListener('click', initGrid);
document.addEventListener('keydown', handleKeydown);

initGrid();