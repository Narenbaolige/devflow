"""Gomoku (五子棋) game implementation."""


class Board:
    """15x15 Gomoku board."""

    def __init__(self):
        self.size = 15
        self.board = [[' ' for _ in range(self.size)] for _ in range(self.size)]
        self.current_player = 'X'  # Black goes first

    def place_stone(self, row: int, col: int) -> bool:
        """Place a stone at (row, col). Returns True if successful, False otherwise."""
        if not (0 <= row < self.size and 0 <= col < self.size):
            return False
        if self.board[row][col] != ' ':
            return False
        self.board[row][col] = self.current_player
        self.current_player = 'O' if self.current_player == 'X' else 'X'
        return True

    def check_win(self, row: int, col: int) -> bool:
        """Check if the last move at (row, col) results in a win."""
        player = self.board[row][col]
        if player == ' ':
            return False

        directions = [
            (0, 1),   # horizontal
            (1, 0),   # vertical
            (1, 1),   # diagonal down-right
            (1, -1),  # diagonal down-left
        ]

        for dr, dc in directions:
            count = 1
            # Check forward direction
            r, c = row + dr, col + dc
            while 0 <= r < self.size and 0 <= c < self.size and self.board[r][c] == player:
                count += 1
                r += dr
                c += dc
            # Check backward direction
            r, c = row - dr, col - dc
            while 0 <= r < self.size and 0 <= c < self.size and self.board[r][c] == player:
                count += 1
                r -= dr
                c -= dc
            if count >= 5:
                return True
        return False

    def is_full(self) -> bool:
        """Check if the board is full (draw)."""
        for row in self.board:
            if ' ' in row:
                return False
        return True

    def display(self) -> None:
        """Print the current board state."""
        print('  ' + ' '.join(str(i % 10) for i in range(self.size)))
        for i, row in enumerate(self.board):
            print(f"{i % 10} " + ' '.join(row))


def main():
    """Command-line interface for Gomoku game."""
    board = Board()
    print("Welcome to Gomoku (五子棋)!")
    print("Black (X) goes first. Enter coordinates as 'row,col' (e.g., '7,7').")
    print("Enter 'q' to quit.")
    board.display()

    while True:
        player = 'X' if board.current_player == 'O' else 'O'  # current_player already switched after last move
        # Actually, current_player is the next player, so we need to determine who just played
        # Let's track the last player
        last_player = 'O' if board.current_player == 'X' else 'X'
        print(f"Player {last_player}'s turn.")
        user_input = input("Enter row,col: ").strip()
        if user_input.lower() == 'q':
            print("Game quit.")
            break
        try:
            parts = user_input.split(',')
            if len(parts) != 2:
                print("Invalid input. Please enter row,col.")
                continue
            row = int(parts[0].strip())
            col = int(parts[1].strip())
        except ValueError:
            print("Invalid input. Please enter integers.")
            continue

        if not board.place_stone(row, col):
            print("Invalid move. Try again.")
            continue

        board.display()

        if board.check_win(row, col):
            print(f"Player {last_player} wins!")
