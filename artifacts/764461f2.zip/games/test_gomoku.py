"""Tests for gomoku.py."""

import pytest
from games.gomoku import Board


class TestBoard:
    def test_initialization(self):
        """Board should be 15x15 and empty."""
        board = Board()
        assert board.size == 15
        assert len(board.board) == 15
        for row in board.board:
            assert len(row) == 15
            assert all(cell == ' ' for cell in row)
        assert board.current_player == 'X'

    def test_place_stone_valid(self):
        """Placing a stone should succeed and switch player."""
        board = Board()
        assert board.place_stone(7, 7) is True
        assert board.board[7][7] == 'X'
        assert board.current_player == 'O'

    def test_place_stone_out_of_bounds(self):
        """Placing a stone out of bounds should fail."""
        board = Board()
        assert board.place_stone(-1, 0) is False
        assert board.place_stone(0, 15) is False
        assert board.place_stone(15, 0) is False
        assert board.current_player == 'X'

    def test_place_stone_occupied(self):
        """Placing a stone on an occupied cell should fail."""
        board = Board()
        board.place_stone(7, 7)
        assert board.place_stone(7, 7) is False
        assert board.board[7][7] == 'X'
        assert board.current_player == 'O'

    def test_check_win_horizontal(self):
        """Five in a row horizontally should be a win."""
        board = Board()
        for col in range(5):
            board.place_stone(7, col)  # X
            if col < 4:
                board.place_stone(8, col)  # O (block not needed, just alternate)
        # Last move was X at (7,4)
        assert board.check_win(7, 4) is True

    def test_check_win_vertical(self):
        """Five in a row vertically should be a win."""
        board = Board()
        for row in range(5):
            board.place_stone(row, 7)  # X
            if row < 4:
                board.place_stone(row, 8)  # O
        assert board.check_win(4, 7) is True

    def test_check_win_diagonal_down_right(self):
        """Five in a row diagonally (down-right) should be a win."""
        board = Board()
        for i in range(5):
            board.place_stone(i, i)  # X
            if i < 4:
                board.place_stone(i, i + 10)  # O (far away to not interfere)
        assert board.check_win(4, 4) is True

    def test_check_win_diagonal_down_left(self):
        """Five in a row diagonally (down-left) should be a win."""
        board = Board()
        for i in range(5):
            board.place_stone(i, 4 - i)  # X
            if i < 4:
                board.place_stone(i, 10 + i)  # O
        assert board.check_win(4, 0) is True

    def test_no_win(self):
        """Less than five in a row should not be a win."""
        board = Board()
        for col in range(4):
            board.place_stone(7, col)  # X
            board.place_stone(8, col)  # O
        # Now it's X's turn again, place a stone elsewhere
        board.place_stone(0, 0)  # X
        # Check the last move (0,0) - no win
        assert board.check_win(0, 0) is False

    def test_is_full_false(self):
        """Board should not be full initially."""
        board = Board()
        assert board.is_full() is False

    def test_is_full_true(self):
        """Board should be full when all cells are occupied."""
        board = Board()
        # Fill the board with alternating stones
        for row in range(15):
            for col in range(15):
                board.board[row][col] = 'X' if (row + col) % 2 == 0 else 'O'
        assert board.is_full() is True

    def test_player_switch(self):
        """Players should alternate correctly."""
        board = Board()
        assert board.current_player == 'X'
        board.place_stone(0, 0)
