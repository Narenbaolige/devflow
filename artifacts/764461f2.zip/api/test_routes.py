"""Tests for routes.py — task-016."""
from api.routes import build_pagination_url


class TestBuildPaginationURL:
    def test_default_page_size(self):
        url = build_pagination_url("users", 1)
        assert "size=20" in url
        assert "/api/v1/users" in url

    def test_caps_at_max(self):
        url = build_pagination_url("items", 1, size=500)
        assert "size=100" in url

    def test_custom_valid_size(self):
        url = build_pagination_url("posts", 2, size=50)
        assert "page=2" in url
        assert "size=50" in url
