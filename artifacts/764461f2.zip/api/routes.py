"""Routes module — task-016: extract hardcoded strings to constants.py."""

from utils.constants import DEFAULT_PAGE_SIZE, MAX_PAGE_SIZE, API_VERSION


def build_pagination_url(base: str, page: int, size: int = DEFAULT_PAGE_SIZE) -> str:
    """Build a paginated API URL."""
    size = min(size, MAX_PAGE_SIZE)
    return f"/api/{API_VERSION}/{base}?page={page}&size={size}"
