"""Bubble sort implementation."""


def bubble_sort(arr):
    """Sort a list using bubble sort algorithm.

    Args:
        arr: List of comparable elements.

    Returns:
        A new sorted list (does not modify the original).

    Raises:
        TypeError: If input is not a list.
    """
    if not isinstance(arr, list):
        raise TypeError(f"Expected list, got {type(arr).__name__}")

    result = list(arr)
    n = len(result)

    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            if result[j] > result[j + 1]:
                result[j], result[j + 1] = result[j + 1], result[j]
                swapped = True
        if not swapped:
            break

    return result
