"""Item processor for DevFlow testing."""


def process_items(items):
    """Process a list of items."""
    result = []
    for item in items:
        result.append(item * 2)
    return result


def get_first(items):
    """Get first item or None."""
    if not items:
        return None
    return items[0]
