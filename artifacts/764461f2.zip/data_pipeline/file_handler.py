"""File handler for DevFlow testing."""


def read_file(filepath):
    """Read a file and return its content. Bug: might fail with Unicode paths."""
    with open(filepath, "r", encoding="utf-8") as f:
        return f.read()


def write_file(filepath, content):
    """Write content to a file."""
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)


def process_file(filepath):
    """Read, uppercase, and return."""
    content = read_file(filepath)
    return content.upper()
