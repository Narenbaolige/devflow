"""Tests for data_pipeline.py — task-018."""
from data_pipeline.data_pipeline import DataPipeline


class TestDataPipeline:
    def test_extract_filters_none(self):
        p = DataPipeline([1, None, 2, None, 3])
        p.extract()
        assert p.extracted == [1, 2, 3]

    def test_transform_doubles(self):
        p = DataPipeline([1, 2, 3])
        p.extract()
        p.transform()
        assert p.transformed == [2, 4, 6]

    def test_load_copies(self):
        p = DataPipeline([1, 2])
        p.extract()
        p.transform()
        p.load()
        assert p.loaded == [2, 4]

    def test_run_uses_individual_methods(self):
        """run() should delegate to extract/transform/load, not duplicate logic."""
        import inspect
        source = inspect.getsource(DataPipeline.run)
        # Should call self.extract/transform/load rather than inlining everything
        assert "self.extract()" in source or "self.transform()" in source
