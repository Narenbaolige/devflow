"""Configuration loader for DevFlow testing."""

import json
from pathlib import Path


def parse_config(filepath):
    """Parse a JSON config file. Returns {} if file does not exist."""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}


def load_config(filepath, defaults=None):
    """Load config with defaults."""
    cfg = defaults or {}
    if Path(filepath).exists():
        cfg.update(parse_config(filepath))
    return cfg
