import json
import pytest
import tempfile
from pathlib import Path
from data_pipeline.config_loader import parse_config, load_config


class TestParseConfig:
    def test_valid_file(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump({"key": "value"}, f)
            path = f.name
        try:
            assert parse_config(path) == {"key": "value"}
        finally:
            Path(path).unlink()

    def test_nonexistent_file(self):
        result = parse_config("nonexistent_file_12345.json")
        assert result == {}


class TestLoadConfig:
    def test_with_defaults(self):
        result = load_config("nonexistent.json", {"a": 1})
        assert result == {"a": 1}
