"""Tests for utils.py — task-012."""
from utils.utils import calculate_values, format_result


class TestCalculateValues:
    def test_returns_sum_and_product(self):
        r = calculate_values(3, 4)
        assert r["sum"] == 7
        assert r["product"] == 12

    def test_has_correct_key_name(self):
        r = calculate_values(2, 5)
        # Should be 'calculated_value', not 'calulated_value'
        assert "calculated_value" in r
        assert r["calculated_value"] == 20


class TestFormatResult:
    def test_format(self):
        assert format_result({"a": 1, "b": 2}) == "a=1, b=2"


class TestBubbleSort:
    def test_normal_sort(self):
        """输入 [3, 1, 2] 应返回 [1, 2, 3]"""
        from utils.utils import bubble_sort
        assert bubble_sort([3, 1, 2]) == [1, 2, 3]

    def test_empty_list(self):
        """输入空列表 [] 应返回 []"""
        from utils.utils import bubble_sort
        assert bubble_sort([]) == []

    def test_single_element(self):
        """输入 [5] 应返回 [5]"""
        from utils.utils import bubble_sort
        assert bubble_sort([5]) == [5]

    def test_already_sorted(self):
        """输入 [1, 2, 3] 应返回 [1, 2, 3]（已排序列表保持不变）"""
        from utils.utils import bubble_sort
        assert bubble_sort([1, 2, 3]) == [1, 2, 3]

    def test_duplicates(self):
        """输入 [4, 4, 2, 2] 应返回 [2, 2, 4, 4]（正确处理重复元素）"""
        from utils.utils import bubble_sort
        assert bubble_sort([4, 4, 2, 2]) == [2, 2, 4, 4]

    def test_does_not_modify_original(self):
        """bubble_sort 不应修改原始列表"""
        from utils.utils import bubble_sort
        original = [3, 1, 2]
        bubble_sort(original)
