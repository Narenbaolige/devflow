"""Search utilities for DevFlow testing."""


def binary_search(arr, target):
    """Binary search."""
    left, right = 0, len(arr) - 1
    while left <= right:
        mid = (left + right) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    return -1


def linear_search(arr, target):
    """Linear search."""
    for i, val in enumerate(arr):
        if val == target:
            return i
    return -1
