"""Validators module. Currently empty — validation logic is duplicated in user_service."""

# TODO: validate_user_data function should be extracted here from user_service.py
