"""Application constants."""

# All hardcoded values should be defined here
DEFAULT_PAGE_SIZE = 20
MAX_PAGE_SIZE = 100
API_VERSION = "v1"
