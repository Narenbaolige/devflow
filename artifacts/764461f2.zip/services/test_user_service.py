import pytest
from services.user_service import UserService


@pytest.fixture
def svc():
    return UserService()


class TestUserService:
    def test_create_valid(self, svc):
        u = svc.create("alice", "alice@example.com", 25)
        assert u["email"] == "alice@example.com"

    def test_create_short_username(self, svc):
        with pytest.raises(ValueError):
            svc.create("ab", "a@b.com", 25)

    def test_create_invalid_email(self, svc):
        with pytest.raises(ValueError):
            svc.create("alice", "no-at-sign", 25)

    def test_create_negative_age(self, svc):
        with pytest.raises(ValueError):
            svc.create("alice", "a@b.com", -5)

    def test_update_email(self, svc):
        svc.create("alice", "alice@example.com", 25)
        svc.update("alice", email="bob@example.com")
        assert svc.users["alice"]["email"] == "bob@example.com"

    def test_update_nonexistent(self, svc):
        with pytest.raises(KeyError):
            svc.update("nobody", email="x@y.com")
