"""User service for DevFlow testing. Has duplicated validation logic."""


class UserService:
    def __init__(self):
        self.users = {}

    def create(self, username, email, age):
        # Duplicated validation (also in update)
        if not username or len(username) < 3:
            raise ValueError("Username must be at least 3 characters")
        if not email or "@" not in email:
            raise ValueError("Invalid email")
        if age is not None and age < 0:
            raise ValueError("Age cannot be negative")
        self.users[username] = {"email": email, "age": age}
        return self.users[username]

    def update(self, username, email=None, age=None):
        if username not in self.users:
            raise KeyError(f"User {username} not found")
        # Duplicated validation (same as create)
        if email is not None:
            if "@" not in email:
                raise ValueError("Invalid email")
            self.users[username]["email"] = email
        if age is not None:
            if age < 0:
                raise ValueError("Age cannot be negative")
            self.users[username]["age"] = age
        return self.users[username]
