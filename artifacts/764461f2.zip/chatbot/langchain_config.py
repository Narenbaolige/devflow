import os
from dataclasses import dataclass, field

@dataclass
import os
from dataclasses import dataclass, field

@dataclass
class LangChainConfig:
    """Configuration for LangChain chatbot."""
    openai_api_key: str = field(default_factory=lambda: os.getenv("OPENAI_API_KEY", ""))
    model_name: str = field(default_factory=lambda: os.getenv("OPENAI_MODEL_NAME", "gpt-3.5-turbo"))
    temperature: float = field(default_factory=lambda: float(os.getenv("OPENAI_TEMPERATURE", "0.7")))
    max_tokens: int = field(default_factory=lambda: int(os.getenv("OPENAI_MAX_TOKENS", "1024")))

    def is_valid(self) -> bool:
        """Check if the configuration is valid (API key present)."""
        return bool(self.openai_api_key)
