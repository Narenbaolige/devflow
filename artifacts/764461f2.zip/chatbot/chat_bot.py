from langchain.chains import ConversationChain
from langchain.memory import ConversationBufferMemory
from langchain_openai import ChatOpenAI
from langchain_config import LangChainConfig
from langchain.chains import ConversationChain
from langchain.memory import ConversationBufferMemory
from langchain_openai import ChatOpenAI
from langchain_config import LangChainConfig

class ChatBot:
    """A chatbot using LangChain with conversation memory."""

    def __init__(self, config: LangChainConfig | None = None):
        """Initialize the chatbot with optional config."""
        self.config = config or LangChainConfig()
        if not self.config.is_valid():
            raise ValueError("OpenAI API key is not set. Set OPENAI_API_KEY environment variable.")
        self.llm = ChatOpenAI(
            openai_api_key=self.config.openai_api_key,
            model_name=self.config.model_name,
            temperature=self.config.temperature,
            max_tokens=self.config.max_tokens,
        )
        self.memory = ConversationBufferMemory()
        self.conversation = ConversationChain(
            llm=self.llm,
            memory=self.memory,
        )

    def send_message(self, message: str) -> str:
        """Send a message to the chatbot and get a response."""
        if not message.strip():
            return "Please provide a non-empty message."
        response = self.conversation.predict(input=message)
        return response

    def get_conversation_history(self) -> list[dict]:
        """Return the conversation history as a list of messages."""
        return self.memory.chat_memory.messages
class ChatBot:
    """A chatbot using LangChain with conversation memory."""

    def __init__(self, config: LangChainConfig | None = None):
        if config is None:
            config = LangChainConfig()
        self.config = config
        self.llm = ChatOpenAI(
            openai_api_key=config.openai_api_key,
            model_name=config.model_name,
            temperature=config.temperature,
            max_tokens=config.max_tokens,
            verbose=config.verbose,
        )
        self.memory = ConversationBufferMemory()
        self.conversation = ConversationChain(
            llm=self.llm,
            memory=self.memory,
            verbose=config.verbose,
        )

    def send_message(self, message: str) -> str:
        """Send a message to the chatbot and get a response."""
        return self.conversation.predict(input=message)

    def get_conversation_history(self) -> list[dict]:
        """Return the conversation history as a list of messages."""
        return self.memory.chat_memory.messages
