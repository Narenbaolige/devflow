"""Gomoku (五子棋) game implementation for two players on a 15x15 board."""


class GomokuGame:
    """A simple Gomoku game with a 15x15 board, supporting two players."""

    EMPTY = 0
    BLACK = 1
    WHITE = 2

    def __init__(self):
        """Initialize a 15x15 board and set current player to BLACK."""
        self.board = [[self.EMPTY for _ in range(15)] for _ in range(15)]
        self.current_player = self.BLACK
        self.winner = None
        self.move_count = 0

    def place_stone(self, row: int, col: int) -> bool:
        """Place a stone for the current player at (row, col).

        Args:
            row: Row index (0-14).
            col: Column index (0-14).

        Returns:
            True if the move was valid and placed, False otherwise.
        """
        if self.winner is not None:
            return False
        if row < 0 or row >= 15 or col < 0 or col >= 15:
            return False
        if self.board[row][col] != self.EMPTY:
            return False

        self.board[row][col] = self.current_player
        self.move_count += 1

        if self._check_win(row, col):
            self.winner = self.current_player
        else:
            self.current_player = self.WHITE if self.current_player == self.BLACK else self.BLACK
        return True

    def _check_win(self, row: int, col: int) -> bool:
        """Check if the last move at (row, col) results in a win.

        Checks four directions: horizontal, vertical, diagonal (\), anti-diagonal (/).
        """
        player = self.board[row][col]
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]

        for dr, dc in directions:
            count = 1
            # Check positive direction
            r, c = row + dr, col + dc
            while 0 <= r < 15 and 0 <= c < 15 and self.board[r][c] == player:
                count += 1
                r += dr
                c += dc
            # Check negative direction
            r, c = row - dr, col - dc
            while 0 <= r < 15 and 0 <= c < 15 and self.board[r][c] == player:
                count += 1
                r -= dr
                c -= dc
            if count >= 5:
                return True
        return False

    def is_draw(self) -> bool:
        """Check if the game is a draw (board full and no winner)."""
        return self.winner is None and self.move_count == 225

    def is_game_over(self) -> bool:
        """Check if the game is over (win or draw)."""
        return self.winner is not None or self.is_draw()

    def print_board(self) -> None:
        """Print the current board state to the console."""
        print("  " + " ".join(str(i % 10) for i in range(15)))
        for i, row in enumerate(self.board):
            line = str(i % 10) + " "
            for cell in row:
                if cell == self.EMPTY:
                    line += ". "
                elif cell == self.BLACK:
                    line += "X "
                else:
                    line += "O "
            print(line.rstrip())

    def get_status(self) -> str:
        """Return a string describing the current game status."""
        if self.winner == self.BLACK:
            return "Black wins!"
        elif self.winner == self.WHITE:
            return "White wins!"
        elif self.is_draw():
            return "Draw!"
        else:
            player = "Black" if self.current_player == self.BLACK else "White"
            return f"{player}'s turn"


def main():
    """Command-line interface for playing Gomoku."""
    game = GomokuGame()
    print("Welcome to Gomoku (五子棋)!")
    print("Enter moves as 'row col' (0-14). Type 'quit' to exit.")
    game.print_board()

    while not game.is_game_over():
        print(game.get_status())
        try:
            user_input = input("Enter move: ").strip()
            if user_input.lower() == "quit":
                print("Game exited.")
                return
            parts = user_input.split()
            if len(parts) != 2:
                print("Invalid input. Please enter 'row col'.")
                continue
            row, col = int(parts[0]), int(parts[1])
            if not game.place_stone(row, col):
                print("Invalid move. Try again.")
                continue
            game.print_board()
        except ValueError:
            print("Invalid input. Please enter two integers.")
        except KeyboardInterrupt:
            print("\nGame interrupted.")
            return

    print(game.get_status())


if __name__ == "__main__":
    main()
