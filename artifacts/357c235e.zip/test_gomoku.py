"""Tests for the Gomoku game implementation."""

import pytest
from gomoku import GomokuGame


class TestGomokuGame:
    def test_initial_board_empty(self):
        """Board should be all EMPTY after initialization."""
        game = GomokuGame()
        for row in game.board:
            for cell in row:
                assert cell == GomokuGame.EMPTY

    def test_initial_player_black(self):
        """Current player should be BLACK initially."""
        game = GomokuGame()
        assert game.current_player == GomokuGame.BLACK

    def test_place_stone_valid(self):
        """Placing a stone on an empty cell should succeed."""
        game = GomokuGame()
        assert game.place_stone(7, 7) is True
        assert game.board[7][7] == GomokuGame.BLACK

    def test_place_stone_occupied(self):
        """Placing a stone on an occupied cell should fail."""
        game = GomokuGame()
        game.place_stone(7, 7)
        assert game.place_stone(7, 7) is False

    def test_place_stone_out_of_bounds(self):
        """Placing a stone outside the board should fail."""
        game = GomokuGame()
        assert game.place_stone(-1, 0) is False
        assert game.place_stone(0, 15) is False
        assert game.place_stone(15, 0) is False

    def test_switch_player_after_move(self):
        """After a valid move, the current player should switch."""
        game = GomokuGame()
        game.place_stone(0, 0)
        assert game.current_player == GomokuGame.WHITE

    def test_horizontal_win(self):
        """Five in a row horizontally should win."""
        game = GomokuGame()
        # Black places at (7,0) to (7,4)
        for col in range(5):
            game.place_stone(7, col)
            if col < 4:
                # White places somewhere else
                game.place_stone(8, col)
        assert game.winner == GomokuGame.BLACK
        assert game.is_game_over() is True

    def test_vertical_win(self):
        """Five in a row vertically should win."""
        game = GomokuGame()
        for row in range(5):
            game.place_stone(row, 0)
            if row < 4:
                game.place_stone(row, 1)
        assert game.winner == GomokuGame.BLACK

    def test_diagonal_win(self):
        """Five in a row diagonally (\) should win."""
        game = GomokuGame()
        for i in range(5):
            game.place_stone(i, i)
            if i < 4:
                game.place_stone(i, i + 5)
        assert game.winner == GomokuGame.BLACK

    def test_anti_diagonal_win(self):
        """Five in a row anti-diagonally (/) should win."""
        game = GomokuGame()
        for i in range(5):
            game.place_stone(i, 4 - i)
            if i < 4:
                game.place_stone(i, 4 - i + 5)
        assert game.winner == GomokuGame.BLACK

    def test_draw(self):
        """Board full with no winner should be a draw."""
        game = GomokuGame()
        # Fill board with alternating pattern that doesn't create five in a row
        # This is a simplified draw scenario: fill all cells without any five in a row
        # We'll use a pattern that guarantees no five in a row
        for row in range(15):
            for col in range(15):
                # Alternate players based on position
                if (row + col) % 2 == 0:
                    game.board[row][col] = GomokuGame.BLACK
                else:
                    game.board[row][col] = GomokuGame.WHITE
        game.move_count = 225
        # Ensure no winner was set
        game.winner = None
        assert game.is_draw() is True
        assert game.is_game_over() is True

    def test_game_over_after_win(self):
        """Game should be over after a win."""
        game = GomokuGame()
        for col in range(5):
            game.place_stone(0, col)
            if col < 4:
                game.place_stone(1, col)
        assert game.is_game_over() is True

    def test_game_not_over_initially(self):
        """Game should not be over initially."""
        game = GomokuGame()
        assert game.is_game_over() is False

    def test_place_stone_after_win_fails(self):
        """Placing a stone after the game is won should fail."""
        game = GomokuGame()
        for col in range(5):
            game.place_stone(0, col)
            if col < 4:
                game.place_stone(1, col)
        assert game.place_stone(2, 0) is False

    def test_get_status_black_turn(self):
        """Status should indicate Black's turn at start."""
        game = GomokuGame()
        assert game.get_status() == "Black's turn"

    def test_get_status_white_turn(self):
        """Status should indicate White's turn after first move."""
        game = GomokuGame()
        game.place_stone(0, 0)
        assert game.get_status() == "White's turn"

    def test_get_status_black_wins(self):
        """Status should declare Black wins."""
        game = GomokuGame()
        for col in range(5):
            game.place_stone(0, col)
            if col < 4:
                game.place_stone(1, col)
        assert game.get_status() == "Black wins!"

    def test_get_status_draw(self):
        """Status should declare Draw."""
        game = GomokuGame()
