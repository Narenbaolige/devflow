# DevFlow Test Repo

DevFlow 多 Agent 协同开发平台的测试仓库。全部测试通过。

> 📂 [github.com/Narenbaolige/devflow](https://github.com/Narenbaolige/devflow)

---

## 项目结构

```
devflow-test-repo/
│
├── games/
│   ├── 2048/              # 🎮 2048 网页游戏 (HTML/CSS/JS)
│   ├── gomoku.py          # 五子棋 (12 tests)
│   ├── calculator.py      # 计算器 (8 tests)
│   └── test_*.py
│
├── sorting/               # 🔢 选择排序 (5 tests)
├── chatbot/               # 🤖 LangChain 聊天机器人
├── data_pipeline/         # 📊 数据处理管线
├── utils/                 # 🛠 工具函数
├── services/              # 🔧 后端服务
├── api/                   # 🌐 API 路由
├── src/                   # 冒泡排序 (8 tests)
└── tests/                 # 冒泡排序测试
```

---

## 测试覆盖

| 模块 | 测试数 | 状态 |
|------|:------:|:----:|
| games/2048 | — | 🟢 网页游戏 |
| games/gomoku | 12 | ✅ |
| games/calculator | 8 | ✅ |
| sorting | 5 | ✅ |
| data_pipeline | 4 | ✅ |
| utils | 25 | ✅ |
| services | 4 | ✅ |
| api | 4 | ✅ |
| src/bubble_sort | 8 | ✅ |

```bash
pytest . -v
```

---

## 生成工具

本仓库所有代码由 [DevFlow](https://github.com/Narenbaolige/devflow) 自动生成。
