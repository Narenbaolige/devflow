import pytest
from sorting.shell_sort import shell_sort


def test_normal_array():
    arr = [64, 34, 25, 12, 22, 11, 90]
    expected = sorted(arr)
    result = shell_sort(arr)
    assert result == expected
    # 验证原地排序
    assert result is arr


def test_empty_array():
    arr = []
    result = shell_sort(arr)
    assert result == []
    assert result is arr


def test_single_element():
    arr = [42]
    result = shell_sort(arr)
    assert result == [42]
    assert result is arr


def test_negative_numbers():
    arr = [-5, 3, -1, 0, -10, 8]
    expected = sorted(arr)
    result = shell_sort(arr)
    assert result == expected


def test_duplicates():
    arr = [5, 1, 3, 5, 2, 3, 1]
    expected = sorted(arr)
    result = shell_sort(arr)
    assert result == expected


def test_already_sorted():
    arr = [1, 2, 3, 4, 5]
    expected = sorted(arr)
    result = shell_sort(arr)
    assert result == expected


def test_reverse_sorted():
    arr = [5, 4, 3, 2, 1]
    expected = sorted(arr)
    result = shell_sort(arr)
    assert result == expected


def test_large_array():
    arr = list(range(1000, 0, -1))
