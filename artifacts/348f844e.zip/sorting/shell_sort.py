def shell_sort(arr):
    """希尔排序，使用Hibbard增量序列，原地排序。

    参数:
        arr: list[int] — 待排序的整数列表

    返回:
        list[int] — 排序后的列表（原地排序，返回原列表引用）

    时间复杂度:
        平均 O(n^(3/2))，最坏 O(n^(3/2))
    """
    n = len(arr)
    # 生成Hibbard增量序列: 2^k - 1, 直到小于n
    gaps = []
    k = 1
    while True:
        gap = (1 << k) - 1  # 2^k - 1
        if gap >= n:
            break
        gaps.append(gap)
        k += 1
    # 从大到小使用增量
    for gap in reversed(gaps):
        for i in range(gap, n):
            temp = arr[i]
            j = i
            while j >= gap and arr[j - gap] > temp:
                arr[j] = arr[j - gap]
                j -= gap
            arr[j] = temp
    return arr
