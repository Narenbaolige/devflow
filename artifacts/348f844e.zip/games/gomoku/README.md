# Gomoku (五子棋)

A simple Gomoku (Five in a Row) game implemented in Python. Players take turns placing stones on a 15x15 board, aiming to get five consecutive stones in a row (horizontally, vertically, or diagonally).

## Project Structure

- `gomoku.py` — Core game logic: board representation, move validation, win detection.
- `test_gomoku.py` — Unit tests for the game logic.

## Installation

No external dependencies are required. The project uses only the Python standard library.

1. Ensure you have Python 3.11 or later installed.
2. Clone or download the repository.
3. Navigate to the `games/gomoku/` directory.

## Usage

### Running the Game

You can run the game interactively from the command line:

```bash
python gomoku.py
```

Follow the prompts to enter moves. Moves are specified as `row,col` (e.g., `7,7` for the center). The game will display the board after each move and announce the winner.

### Running Tests

To run the unit tests, use pytest:

```bash
pytest test_gomoku.py -v
```

## Game Rules

- The board is 15x15 (rows and columns numbered 0–14).
- Two players: Black (X) and White (O). Black moves first.
- Players alternate placing one stone per turn on an empty intersection.
- The first player to get five consecutive stones in a row (horizontally, vertically, or diagonally) wins.
- If the board is full with no winner, the game is a draw.

## API Overview

### `Gomoku` class

- `__init__()` — Initializes an empty 15x15 board and sets the current player to Black.
- `make_move(row, col)` — Places a stone at the given position. Returns `True` if the move is valid and made, `False` otherwise.
- `check_winner()` — Returns `'X'` if Black wins, `'O'` if White wins, or `None` if no winner yet.
- `is_board_full()` — Returns `True` if all cells are occupied.
- `get_board()` — Returns a copy of the current board (list of lists).
- `get_current_player()` — Returns `'X'` or `'O'`.

## License

This project is for educational purposes.