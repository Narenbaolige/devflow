# DevFlow Test Repo

## 项目简介

DevFlow Test Repo 是一个用于测试 DevFlow 工作流的示例仓库。它包含一个简单的 Python 数学工具库，提供基础的数学运算函数，如阶乘、斐波那契数列和排序算法。

## 安装说明

1. 确保已安装 Python 3.11 或更高版本。
2. 克隆仓库：
   ```bash
   git clone https://github.com/Narenbaolige/devflow-test-repo.git
   cd devflow-test-repo
   ```
3. （可选）创建虚拟环境：
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   venv\Scripts\activate  # Windows
   ```
4. 安装依赖：
   ```bash
   pip install -r requirements.txt
   ```

## 使用示例

### 阶乘

```python
from math_utils import factorial

print(factorial(5))  # 输出: 120
```

### 斐波那契数列

```python
from math_utils import fibonacci

print(fibonacci(10))  # 输出: [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]
```

### 冒泡排序

```python
from math_utils import bubble_sort

print(bubble_sort([3, 1, 4, 1, 5, 9, 2, 6]))  # 输出: [1, 1, 2, 3, 4, 5, 6, 9]
```

## 贡献指南

欢迎贡献！请遵循以下步骤：

1. Fork 本仓库。
2. 创建您的特性分支 (`git checkout -b feature/AmazingFeature`)。
3. 提交您的更改 (`git commit -m 'Add some AmazingFeature'`)。
4. 推送到分支 (`git push origin feature/AmazingFeature`)。
5. 打开一个 Pull Request。

请确保您的代码通过所有测试，并添加新的测试以覆盖新功能。

## 许可证

本项目采用 MIT 许可证。