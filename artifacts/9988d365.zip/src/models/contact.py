"""Contact model representing a person with name and phone number."""


class Contact:
    """A contact entity with name and phone number.

    Attributes:
        name: The display name of the contact.
        phone_number: The phone number as a string.
    """

    def __init__(self, name: str, phone_number: str) -> None:
        self.name = name
        self.phone_number = phone_number

    def __repr__(self) -> str:
        return f"Contact(name={self.name!r}, phone_number={self.phone_number!r})"


# Predefined sample contacts, including the required "那仁宝力格"
SAMPLE_CONTACTS: list[Contact] = [
    Contact(name="那仁宝力格", phone_number="+8613800138000"),
]
