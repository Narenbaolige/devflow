"""SMS gateway interface and a configurable mock implementation."""
from __future__ import annotations

from abc import ABC, abstractmethod


class SmsGateway(ABC):
    """Abstract interface for sending SMS messages."""

    @abstractmethod
    def send(self, phone_number: str, message: str) -> bool:
        """Send an SMS message.

        Args:
            phone_number: Destination phone number.
            message: Text content of the message.

        Returns:
            True if the message was sent successfully.

        Raises:
            ConnectionError: If a network-level error occurs.
            ValueError: If the phone number format is invalid.
        """
        ...


class MockSmsGateway(SmsGateway):
    """Configurable mock gateway that can simulate success or failure.

    When set to success mode, prints a log line and returns True.
    When set to failure mode, raises a ConnectionError.
    """

    def __init__(self, should_succeed: bool = True) -> None:
        self.should_succeed = should_succeed

    def send(self, phone_number: str, message: str) -> bool:
        """Simulate sending an SMS."""
        # Optional basic validation
        if not phone_number.startswith("+"):
            raise ValueError("Phone number must start with '+'")

        if not self.should_succeed:
            raise ConnectionError("Simulated network error")

        print(f"[MockSmsGateway] SMS sent to {phone_number}: {message}")
        return True
