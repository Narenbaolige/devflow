"""Command-line UI for composing and sending SMS messages."""
from __future__ import annotations

from src.models.contact import Contact, SAMPLE_CONTACTS
from src.services.sms.sms_service import SmsService


def _find_contact_by_name(name: str) -> Contact | None:
    """Return a contact from SAMPLE_CONTACTS whose name matches exactly."""
    for contact in SAMPLE_CONTACTS:
        if contact.name == name:
            return contact
    return None


def run_message_compose_dialog(service: SmsService) -> None:
    """Interactive loop to compose and send an SMS.

    The user is prompted for a recipient name. If the name is not found
    in the predefined list, a new contact is created after asking for
    a phone number. The user then enters a message and the service
    sends it, displaying the result.
    """
    print("===== 短信发送 =====\n")

    while True:
        recipient_name = input("请输入收件人姓名 (留空退出): ").strip()
        if not recipient_name:
            print("已退出。")
            break

        contact = _find_contact_by_name(recipient_name)
        if contact is None:
            print(f"未找到联系人 '{recipient_name}'。")
            phone = input("请输入电话号码（例如 +8613800138000）: ").strip()
            if not phone:
                print("电话号不能为空，操作取消。")
                continue
            contact = Contact(name=recipient_name, phone_number=phone)

        message = input("请输入短信内容: ").strip()
        if not message:
            print("短信内容不能为空，操作取消。")
            continue

        try:
            service.send_sms(contact, message)
            print(f"短信已成功发送给 {contact.name}")
        except ConnectionError as e:
            print(f"❌ 发送失败：网络错误，请稍后重试。（{e}）")
        except Exception as e:
            print(f"❌ 发送失败：{e}")
