"""SMS service that orchestrates sending via a gateway."""
from __future__ import annotations

from src.integrations.sms_gateway import SmsGateway
from src.models.contact import Contact


class SmsService:
    """Service layer for sending SMS messages to contacts."""

    def __init__(self, gateway: SmsGateway) -> None:
        self._gateway = gateway

    def send_sms(self, contact: Contact, message: str) -> bool:
        """Send an SMS message to the given contact.

        Args:
            contact: The recipient contact.
            message: The message body.

        Returns:
            True if the message was sent successfully.

        Raises:
            ConnectionError: If the underlying gateway fails.
            ValueError: If the message is empty.
        """
        if not message.strip():
            raise ValueError("Message cannot be empty")

        return self._gateway.send(contact.phone_number, message)
