"""Unit tests for the SMS messaging components."""
from __future__ import annotations

import io
import sys
from contextlib import redirect_stdout
from unittest import mock

import pytest

from src.models.contact import Contact, SAMPLE_CONTACTS
from src.integrations.sms_gateway import MockSmsGateway
from src.services.sms.sms_service import SmsService
from src.ui.message_compose_dialog import _find_contact_by_name, run_message_compose_dialog


# ---------------------------------------------------------------------------
# Contact model tests
# ---------------------------------------------------------------------------

class TestContactModel:
    def test_create_contact(self) -> None:
        c = Contact("那仁宝力格", "+8613800138000")
        assert c.name == "那仁宝力格"
        assert c.phone_number == "+8613800138000"

    def test_repr(self) -> None:
        c = Contact("Test", "+123")
        assert repr(c) == "Contact(name='Test', phone_number='+123')"

    def test_sample_contacts_contains_target(self) -> None:
        names = [c.name for c in SAMPLE_CONTACTS]
        assert "那仁宝力格" in names


# ---------------------------------------------------------------------------
# MockSmsGateway tests
# ---------------------------------------------------------------------------

class TestMockSmsGateway:
    def test_successful_send(self) -> None:
        gw = MockSmsGateway(should_succeed=True)
        result = gw.send("+8613800138000", "Hello")
        assert result is True

    def test_successful_send_prints_message(self) -> None:
        gw = MockSmsGateway(should_succeed=True)
        buf = io.StringIO()
        with redirect_stdout(buf):
            gw.send("+8613800138000", "Hello")
        output = buf.getvalue()
        assert "[MockSmsGateway] SMS sent to" in output
        assert "Hello" in output

    def test_failure_raises_connection_error(self) -> None:
        gw = MockSmsGateway(should_succeed=False)
        with pytest.raises(ConnectionError, match="network error"):
            gw.send("+8613800138000", "Hello")

    def test_invalid_phone_number_raises_value_error(self) -> None:
        gw = MockSmsGateway(should_succeed=True)
        with pytest.raises(ValueError, match=r"must start with '\+'"):
            gw.send("12345", "Hello")


# ---------------------------------------------------------------------------
# SmsService tests
# ---------------------------------------------------------------------------

class TestSmsService:
    def test_send_sms_success(self) -> None:
        gw = MockSmsGateway(should_succeed=True)
        svc = SmsService(gw)
        contact = Contact("那仁宝力格", "+8613800138000")
        assert svc.send_sms(contact, "你好") is True

    def test_send_sms_empty_message(self) -> None:
        gw = MockSmsGateway(should_succeed=True)
        svc = SmsService(gw)
        contact = Contact("那仁宝力格", "+8613800138000")
        with pytest.raises(ValueError, match="cannot be empty"):
            svc.send_sms(contact, "   ")

    def test_send_sms_gateway_failure(self) -> None:
        gw = MockSmsGateway(should_succeed=False)
        svc = SmsService(gw)
        contact = Contact("那仁宝力格", "+8613800138000")
        with pytest.raises(ConnectionError, match="network error"):
            svc.send_sms(contact, "你好")


# ---------------------------------------------------------------------------
# MessageComposeDialog tests
# ---------------------------------------------------------------------------

class TestMessageComposeDialogHelpers:
    def test_find_existing_contact(self) -> None:
        c = _find_contact_by_name("那仁宝力格")
        assert c is not None
        assert c.name == "那仁宝力格"

    def test_find_missing_contact(self) -> None:
        c = _find_contact_by_name("不存在")
        assert c is None


class TestMessageComposeDialogIntegration:
    def test_successful_send_flow(self) -> None:
        """Simulate a successful send via the UI loop."""
        gw = MockSmsGateway(should_succeed=True)
        svc = SmsService(gw)

        # Simulate user input: 那仁宝力格 -> 你好 -> empty (exit)
        inputs = iter(["那仁宝力格", "你好", ""])
        with mock.patch("builtins.input", lambda _: next(inputs)):
            buf = io.StringIO()
            with redirect_stdout(buf):
                run_message_compose_dialog(svc)
        output = buf.getvalue()
        assert "短信已成功发送给 那仁宝力格" in output

    def test_new_contact_flow(self) -> None:
        """Simulate creating a new contact and sending."""
        gw = MockSmsGateway(should_succeed=True)
        svc = SmsService(gw)

        # New person, then phone, then message, then exit
        inputs = iter(["新朋友", "+8613900000000", "Hi", ""])
        with mock.patch("builtins.input", lambda _: next(inputs)):
            buf = io.StringIO()
            with redirect_stdout(buf):
                run_message_compose_dialog(svc)
        output = buf.getvalue()
        assert "短信已成功发送给 新朋友" in output

    def test_gateway_failure_shows_error(self) -> None:
        """Simulate a gateway failure and verify error message in output."""
        gw = MockSmsGateway(should_succeed=False)
        svc = SmsService(gw)

        inputs = iter(["那仁宝力格", "你好", ""])
        with mock.patch("builtins.input", lambda _: next(inputs)):
            buf = io.StringIO()
            with redirect_stdout(buf):
                run_message_compose_dialog(svc)
        output = buf.getvalue()
        assert "❌ 发送失败" in output

