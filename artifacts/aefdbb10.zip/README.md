# DevFlow Test Repo

A demonstration repository for testing DevFlow workflows. Contains multiple modules including API routes, a chatbot, data pipeline, games, services, sorting algorithms, and utility functions.

## Installation

1. Ensure Python 3.11 or higher is installed.
2. Clone the repository:
   ```bash
   git clone https://github.com/Narenbaolige/devflow-test-repo.git
   cd devflow-test-repo
   ```
3. (Optional) Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   venv\Scripts\activate  # Windows
   ```
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Modules

### API
- `api/routes.py`: Provides `build_pagination_url()` to construct paginated API URLs using constants from `utils/constants.py`.

### Chatbot
- `chatbot/chat_bot.py`: A LangChain-based chatbot with conversation memory. Uses `ChatOpenAI` and `ConversationChain`.
- `chatbot/langchain_config.py`: Configuration dataclass for the chatbot, reading environment variables.

### Data Pipeline
- `data_pipeline/config_loader.py`: Functions `parse_config()` and `load_config()` for reading JSON configuration files.
- `data_pipeline/data_pipeline.py`: `DataPipeline` class with extract, transform, load steps.
- `data_pipeline/file_handler.py`: Functions `read_file()`, `write_file()`, and `process_file()` for file I/O.
- `data_pipeline/item_processor.py`: Functions `process_items()` and `get_first()` for item processing.

### Games
- `games/calculator.py`: `Calculator` class with basic arithmetic operations (add, subtract, multiply, divide, power).
- `games/gomoku.py`: `Board` class for a 15x15 Gomoku (five-in-a-row) game.
- `games/2048/`: A browser-based 2048 game (HTML, CSS, JavaScript).

### Services
- `services/models.py`: `User` dataclass with name and email.
- `services/user_service.py`: `UserService` class for creating and updating users with validation.

### Sorting
- `sorting/sorting.py`: `selection_sort()` function implementing selection sort.
- `src/bubble_sort.py`: `bubble_sort()` function implementing bubble sort.

### Utils
- `utils/constants.py`: Application constants (`DEFAULT_PAGE_SIZE`, `MAX_PAGE_SIZE`, `API_VERSION`).
- `utils/math_utils.py`: `factorial()` and `fibonacci()` functions.
- `utils/search.py`: `binary_search()` and `linear_search()` functions.
- `utils/utils.py`: `calculate_values()`, `format_result()`, and `bubble_sort()` functions.
- `utils/validators.py`: Placeholder for future validation logic.

## Usage Examples

### Factorial

```python
from utils.math_utils import factorial

print(factorial(5))  # Output: 120
```

### Fibonacci

```python
from utils.math_utils import fibonacci

print(fibonacci(10))  # Output: 55
```

### Bubble Sort (from utils)

```python
from utils.utils import bubble_sort

print(bubble_sort([3, 1, 4, 1, 5, 9, 2, 6]))  # Output: [1, 1, 2, 3, 4, 5, 6, 9]
```

### Selection Sort

```python
from sorting.sorting import selection_sort

print(selection_sort([3, 1, 4, 1, 5, 9, 2, 6]))  # Output: [1, 1, 2, 3, 4, 5, 6, 9]
```

### Calculator

```python
from games.calculator import Calculator

calc = Calculator()
print(calc.add(2, 3))       # Output: 5
print(calc.divide(10, 2))   # Output: 5.0
print(calc.power(2, 3))     # Output: 8
```

### Data Pipeline

```python
from data_pipeline.data_pipeline import DataPipeline

pipeline = DataPipeline([1, None, 2, None, 3])
result = pipeline.run()
print(result)  # Output: [2, 4, 6]
```

### API Pagination URL

```python
from api.routes import build_pagination_url

url = build_pagination_url("users", 1)
print(url)  # Output: /api/v1/users?page=1&size=20
```

### User Service

```python
from services.user_service import UserService

svc = UserService()
svc.create("alice", "alice@example.com", 25)
print(svc.users["alice"])  # Output: {'email': 'alice@example.com', 'age': 25}
```

### Chatbot (requires OpenAI API key)

```python
from chatbot.chat_bot import ChatBot

bot = ChatBot()
response = bot.send_message("Hello!")
print(response)
```

## Testing

Run all tests with pytest:

```bash
pytest
```