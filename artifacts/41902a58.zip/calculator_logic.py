def add(a, b):
    return float(a) + float(b)


def subtract(a, b):
    return float(a) - float(b)


def multiply(a, b):
    return float(a) * float(b)


def divide(a, b):
    try:
        result = float(a) / float(b)
        return result
    except ZeroDivisionError:
        return 'Error'
