import re

def add(a: float, b: float) -> float:
    return a + b

def subtract(a: float, b: float) -> float:
    return a - b

def multiply(a: float, b: float) -> float:
    return a * b

def divide(a: float, b: float):
    if b == 0:
        return 'Cannot divide by zero'
    return a / b

def calculate(num1: float, op: str, num2: float):
    operations = {
        '+': add,
        '-': subtract,
        '*': multiply,
        '/': divide
    }
    func = operations.get(op)
    if func is None:
        return 'Invalid operator'
    return func(num1, num2)

def main():
    print("Simple Calculator (e.g. 3+5= or step by step). Type 'C' to reset, 'q' to quit.")
    num1 = None
    operator = None
    while True:
        line = input('> ').strip()
        if not line:
            continue
        if line.lower() == 'q':
            break
        if line.upper() == 'C' or line.upper() == 'CE':
            num1 = None
            operator = None
            print('[Cleared]')
            continue
        # Try to parse full expression directly, e.g. "3+5="
        match = re.fullmatch(r'([\d.]+)\s*([+\-*/])\s*([\d.]+)\s*=', line)
        if match:
            num1 = float(match.group(1))
            operator = match.group(2)
            num2 = float(match.group(3))
            result = calculate(num1, operator, num2)
            print(f"{num1} {operator} {num2} = {result}")
            num1 = result if isinstance(result, (int, float)) else None
            operator = None
            continue
        # Otherwise step-by-step mode
        try:
            value = float(line)
            if num1 is None:
                num1 = value
                print(f"num1 = {num1}")
            else:
                num2 = value
                if operator is None:
                    print("Need operator first")
                else:
                    result = calculate(num1, operator, num2)
                    print(f"{num1} {operator} {num2} = {result}")
                    num1 = result if isinstance(result, (int, float)) else None
                    operator = None
        except ValueError:
            # It might be an operator (single character + - * /)
