from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort

# DevFlow Test Repo

A demonstration repository for testing DevFlow workflows. Contains multiple modules including API routes, a chatbot, data pipeline, games, services, sorting algorithms, and utility functions.

## Installation

1. Ensure Python 3.11 or higher is installed.
2. Clone the repository:
   ```bash
   git clone https://github.com/Narenbaolige/devflow-test-repo.git
   cd devflow-test-repo
   ```
3. (Optional) Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   venv\Scripts\activate  # Windows
   ```
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Modules

### API
- `api/routes.py`: Provides `build_pagination_url()` to construct paginated API URLs using constants from `utils/constants.py`.

### Chatbot
- `chatbot/chat_bot.py`: A LangChain-based chatbot with conversation memory. Uses `ChatOpenAI` and `ConversationChain`.
- `chatbot/langchain_config.py`: Configuration dataclass for the chatbot, reading environment variables.

### Data Pipeline
- `data_pipeline/config_loader.py`: Functions `parse_config()` and `load_config()` for reading JSON configuration files.
- `data_pipeline/data_pipeline.py`: `DataPipeline` class with extract, transform, load steps.
- `data_pipeline/file_handler.py`: Functions `read_file()`, `write_file()`, and `process_file()` for file I/O.
- `data_pipeline/item_processor.py`: Functions `process_items()` and `get_first()` for item processing.

### Games
- `games/calculator.py`: `Calculator` class with basic arithmetic operations (add, subtract, multiply, divide, power).
- `games/gomoku.py`: `Board` class for a 15x15 Gomoku (five-in-a-row) game.
- `games/2048/`: A browser-based 2048 game (HTML, CSS, JavaScript).

### Services
- `services/models.py`: `User` dataclass with name and email.
- `services/user_service.py`: `UserService` class for creating and updating users with validation.

### Sorting
- `sorting/sorting.py`: `selection_sort()` function implementing selection sort.
- `src/bubble_sort.py`: `bubble_sort()` function implementing bubble sort.

---

# DevFlow 测试仓库

这是一个用于测试 DevFlow 工作流的演示仓库。包含多个模块，包括 API 路由、聊天机器人、数据管道、游戏、服务、排序算法和工具函数。

## 安装

1. 确保已安装 Python 3.11 或更高版本。
2. 克隆仓库：
   ```bash
   git clone https://github.com/Narenbaolige/devflow-test-repo.git
   cd devflow-test-repo
   ```
3. （可选）创建并激活虚拟环境：
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   venv\Scripts\activate  # Windows
   ```
4. 安装依赖：
   ```bash
   pip install -r requirements.txt
   ```

## 模块说明

### API
- `api/routes.py`：提供 `build_pagination_url()` 函数，用于构建分页 API URL，使用 `utils/constants.py` 中的常量。

### 聊天机器人
- `chatbot/chat_bot.py`：基于 LangChain 的聊天机器人，具有对话记忆功能。使用 `ChatOpenAI` 和 `ConversationChain`。
- `chatbot/langchain_config.py`：聊天机器人的配置数据类，读取环境变量。

### 数据管道
- `data_pipeline/config_loader.py`：提供 `parse_config()` 和 `load_config()` 函数，用于读取 JSON 配置文件。
- `data_pipeline/data_pipeline.py`：`DataPipeline` 类，包含提取、转换、加载步骤。
- `data_pipeline/file_handler.py`：提供 `read_file()`、`write_file()` 和 `process_file()` 函数，用于文件 I/O。
- `data_pipeline/item_processor.py`：提供 `process_items()` 和 `get_first()` 函数，用于项目处理。

### 游戏
- `games/calculator.py`：`Calculator` 类，提供基本算术运算（加、减、乘、除、幂）。
- `games/gomoku.py`：`Board` 类，实现 15x15 五子棋游戏。
- `games/2048/`：基于浏览器的 2048 游戏（HTML、CSS、JavaScript）。

### 服务
- `services/models.py`：`User` 数据类，包含姓名和电子邮件。
- `services/user_service.py`：`UserService` 类，用于创建和更新用户，包含验证逻辑。

### 排序
- `sorting/sorting.py`：`selection_sort()` 函数，实现选择排序。
- `src/bubble_sort.py`：`bubble_sort()` 函数，实现冒泡排序。