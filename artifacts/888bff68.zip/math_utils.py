def factorial(n):
    """Return the factorial of a non-negative integer n."""
    if not isinstance(n, int):
        raise TypeError(f"Expected int, got {type(n).__name__}")
    if n < 0:
        return factorial(-n)
    if n == 0:
        return 1
    return n * factorial(n - 1)
