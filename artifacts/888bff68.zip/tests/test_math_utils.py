import pytest
from math_utils import factorial

def test_factorial_non_integer_float():
    with pytest.raises(TypeError, match="Expected int, got float"):
        factorial(3.5)

def test_factorial_non_integer_str():
    with pytest.raises(TypeError, match="Expected int, got str"):
        factorial("abc")

def test_factorial_non_integer_none():
    with pytest.raises(TypeError, match="Expected int, got NoneType"):
        factorial(None)

def test_factorial_negative():
    assert factorial(-5) == 120  # absolute value behavior

def test_factorial_zero():
    assert factorial(0) == 1

def test_factorial_positive():
    assert factorial(5) == 120
