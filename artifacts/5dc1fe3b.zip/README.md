# LangChain Chat Bot

A chat bot built with LangChain and Streamlit, supporting multiple LLM providers (OpenAI, Anthropic) configurable via `config.yaml`.

## Setup

1. Clone the repository
2. Install dependencies: `pip install -r requirements.txt`
3. Copy `.env.example` to `.env` and fill in your API keys:
   - `OPENAI_API_KEY` (if using OpenAI)
   - `ANTHROPIC_API_KEY` (if using Anthropic)
4. Adjust `config.yaml` to select provider, model, temperature, etc.
5. Run the app: `streamlit run app.py`
