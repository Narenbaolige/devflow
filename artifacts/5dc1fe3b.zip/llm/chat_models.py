import os
import yaml
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_anthropic import ChatAnthropic

load_dotenv()

def load_llm_config(config_path="config.yaml"):
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    llm_config = config.get('llm', {})
    provider = llm_config.get('provider', 'openai')
    model_name = llm_config.get('model_name', 'gpt-3.5-turbo')
    temperature = llm_config.get('temperature', 0.7)
    return {
        'provider': provider,
        'model_name': model_name,
        'temperature': temperature,
    }

def create_chat_model(config=None):
    if config is None:
        config = load_llm_config()
    provider = config.get('provider')
    if provider == 'openai':
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY environment variable not set.")
        return ChatOpenAI(
            model=config.get('model_name', 'gpt-3.5-turbo'),
            temperature=config.get('temperature', 0.7),
            openai_api_key=api_key
        )
    elif provider == 'anthropic':
        api_key = os.getenv('ANTHROPIC_API_KEY')
