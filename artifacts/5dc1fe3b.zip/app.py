import streamlit as st
from llm.chat_models import load_llm_config, create_chat_model
from memory.chat_history import get_memory
from chains.conversation_chain import create_conversation_chain

st.set_page_config(page_title="Chat Bot", layout="wide")
st.title("LangChain Chat Bot")

# Initialize session state
if "chain" not in st.session_state:
    try:
        config = load_llm_config()
        llm = create_chat_model(config)
        memory = get_memory()
        chain = create_conversation_chain(llm, memory)
        st.session_state.chain = chain
        st.session_state.messages = []
    except Exception as e:
        st.error(f"Failed to initialize chat model: {str(e)}")
        st.stop()

# Display chat history
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# Chat input
if prompt := st.chat_input("Type your message..."):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)
    
    try:
        response = st.session_state.chain.invoke({"input": prompt})
        reply = response.get("response", "I didn't get that.")
        st.session_state.messages.append({"role": "assistant", "content": reply})
        with st.chat_message("assistant"):
            st.markdown(reply)
    except Exception as e:
