from langchain.chains import ConversationChain

def create_conversation_chain(llm, memory):
    return ConversationChain(llm=llm, memory=memory, verbose=False)
