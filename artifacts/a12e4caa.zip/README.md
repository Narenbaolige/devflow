from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort

from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort

from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort

from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort
from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort
from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort

from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort

from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort

from utils.math_utils import factorial
from utils.math_utils import fibonacci
from utils.utils import bubble_sort

# DevFlow Test Repo

A demonstration repository for testing DevFlow workflows. Contains multiple modules including API routes, a chatbot, data pipeline, games, services, sorting algorithms, and utility functions.

���ڲ��� DevFlow ����������ʾ�ֿ⡣�������ģ�飬���� API ·�ɡ���������ˡ����ݹܵ�����Ϸ�����������㷨�͹��ߺ�����

## Installation

1. Ensure Python 3.11 or higher is installed.
2. Clone the repository:
   ```bash
   git clone https://github.com/Narenbaolige/devflow-test-repo.git
   cd devflow-test-repo
   ```
3. (Optional) Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   venv\Scripts\activate  # Windows
   ```
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## ��װ

1. ȷ���Ѱ�װ Python 3.11 ����߰汾��
2. ��¡�ֿ⣺
   ```bash
   git clone https://github.com/Narenbaolige/devflow-test-repo.git
   cd devflow-test-repo
   ```
3. ����ѡ���������������⻷����
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   venv\Scripts\activate  # Windows

## Project Structure

The repository contains the following files and directories:

```
.
├── .gitignore
├── README.md
├── requirements.txt
├── api/
│   ├── __init__.py
│   ├── routes.py
│   └── test_routes.py
├── chatbot/
│   ├── __init__.py
│   ├── chat_bot.py
│   └── langchain_config.py
├── data_pipeline/
│   ├── __init__.py
│   ├── config_loader.py
│   ├── data_pipeline.py
│   ├── file_handler.py
│   ├── item_processor.py
│   ├── test_config_loader.py
│   ├── test_data_pipeline.py
│   ├── test_file_handler.py
│   └── test_item_processor.py
├── games/
│   ├── __init__.py
│   ├── calculator.py
│   ├── gomoku.py
│   ├── test_calculator.py
│   ├── test_gomoku.py
│   └── 2048/
│       ├── index.html
│       ├── script.js
│       └── style.css
├── services/
│   ├── __init__.py
│   ├── models.py
│   ├── test_user.py
│   ├── test_user_service.py
│   └── user_service.py
├── sorting/
│   ├── __init__.py
│   ├── sorting.py
│   └── test_sorting.py
├── src/
│   └── bubble_sort.py
├── tests/
│   └── test_bubble_sort.py
└── utils/
    ├── __init__.py
    ├── constants.py
    ├── math_utils.py
    ├── search.py
    ├── test_math_utils.py
    ├── test_search.py
    ├── test_utils.py
    ├── utils.py
    └── validators.py
```
