import pytest
from search import binary_search, linear_search


class TestBinarySearch:
    def test_find_first(self):
        assert binary_search([1, 2, 3, 4, 5], 1) == 0

    def test_find_last(self):
        assert binary_search([1, 2, 3, 4, 5], 5) == 4

    def test_find_middle(self):
        assert binary_search([1, 2, 3, 4, 5], 3) == 2

    def test_not_found(self):
        assert binary_search([1, 2, 3, 4, 5], 99) == -1

    def test_empty(self):
        assert binary_search([], 1) == -1

    def test_single_element(self):
        assert binary_search([42], 42) == 0


class TestLinearSearch:
    def test_find(self):
        assert linear_search([1, 2, 3], 2) == 1

    def test_not_found(self):
        assert linear_search([1, 2, 3], 99) == -1
