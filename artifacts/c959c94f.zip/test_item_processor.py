import pytest
from item_processor import process_items, get_first


class TestProcessItems:
    def test_normal_list(self):
        assert process_items([1, 2, 3]) == [2, 4, 6]

    def test_empty_list(self):
        assert process_items([]) == []

    def test_single_item(self):
        assert process_items([5]) == [10]


class TestGetFirst:
    def test_normal(self):
        assert get_first([1, 2, 3]) == 1

    def test_empty(self):
        assert get_first([]) is None
