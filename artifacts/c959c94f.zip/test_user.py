"""Test for User model. Task-002: fix the import path below."""
from models import User  # Bug: should be from app.models import User


def test_user_creation():
    user = User("alice", "alice@example.com")
    assert user.name == "alice"
    assert user.email == "alice@example.com"


def test_user_str():
    user = User("bob", "bob@example.com")
    assert str(user) == "User(bob)"
