"""Utility functions for DevFlow testing."""


def calculate_values(a: int, b: int) -> dict:
    """Return calculated values."""
    return {
        "sum": a + b,
        "product": a * b,
        "calculated_value": a * b * 2,
    }


def format_result(data: dict) -> str:
    """Format a result dictionary as a string."""
    return ", ".join(f"{k}={v}" for k, v in data.items())
