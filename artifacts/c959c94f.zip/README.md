"""

"""

# DevFlow Test Repository

A test repository for practicing DevFlow workflows. Contains various Python modules with intentional bugs and tasks for development exercises.

## Project Structure

```
.
├── calculator.py              # Simple calculator class (add, subtract, multiply, divide)
├── config_loader.py           # JSON configuration loader with defaults
├── constants.py               # Application constants (page size, API version)
├── data_pipeline.py           # Data pipeline with extract, transform, load stages
├── file_handler.py            # File read/write/process utilities
├── item_processor.py          # Item processing and retrieval functions
├── math_utils.py              # Factorial and Fibonacci implementations
├── models.py                  # User model (dataclass)
├── routes.py                  # Pagination URL builder using constants
├── search.py                  # Binary and linear search algorithms
├── src/
│   └── bubble_sort.py         # Bubble sort implementation
├── user_service.py            # User CRUD service with validation
├── utils.py                   # Utility functions (calculate_values, format_result)
├── validators.py              # Validators module (currently empty)
├── test_calculator.py         # Tests for calculator
├── test_config_loader.py      # Tests for config_loader
├── test_data_pipeline.py      # Tests for data_pipeline
├── test_file_handler.py       # Tests for file_handler
├── test_item_processor.py     # Tests for item_processor
├── test_math_utils.py         # Tests for math_utils
├── test_routes.py             # Tests for routes
├── test_search.py             # Tests for search
├── test_user.py               # Tests for User model
├── test_user_service.py       # Tests for user_service
├── test_utils.py              # Tests for utils
├── tests/
│   └── test_bubble_sort.py    # Tests for bubble_sort
├── README.md                  # This file
└── .gitignore                 # Git ignore rules
```

## Module Descriptions

### calculator.py
Provides a `Calculator` class with basic arithmetic operations: `add`, `subtract`, `multiply`, `divide`. The `divide` method returns `None` for division by zero.

### config_loader.py
Contains `parse_config` and `load_config` functions for reading JSON configuration files. `load_config` supports default values if the file does not exist.

### constants.py
Defines application-wide constants: `DEFAULT_PAGE_SIZE`, `MAX_PAGE_SIZE`, and `API_VERSION`.

### data_pipeline.py
Implements a `DataPipeline` class with `extract`, `transform`, and `load` stages. The `run` method orchestrates the pipeline.

### file_handler.py
Provides `read_file`, `write_file`, and `process_file` (uppercase) functions for file operations.

### item_processor.py
Contains `process_items` (doubles each item) and `get_first` (returns first item or `None`) functions.

### math_utils.py
Implements `factorial` (recursive) and `fibonacci` (recursive) functions.

### models.py
Defines a simple `User` class with `name` and `email` attributes.

### routes.py
Provides `build_pagination_url` to construct paginated API URLs using constants from `constants.py`.

### search.py
Implements `binary_search` and `linear_search` algorithms.

### src/bubble_sort.py
Implements the bubble sort algorithm. Returns a new sorted list without modifying the input.

### user_service.py
Provides `UserService` class with `create` and `update` methods, including input validation.

### utils.py
Contains `calculate_values` (returns sum, product, and a calculated value) and `format_result` (formats a dict as a string).

### validators.py
Currently empty; intended for extracted validation logic.

## Installation

No external dependencies are required. The project uses Python's standard library only.

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd devflow-test-repo
   ```

2. (Optional) Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

## Running Tests

Tests are written using `pytest`. To run all tests:

```bash
pytest
```

To run a specific test file:

```bash
pytest test_calculator.py
```

To run tests with verbose output:

```bash
pytest -v
```

## Notes

- Some modules contain intentional bugs for practice purposes.
- The project is designed for DevFlow workflow exercises.