"""Tests for utils.py — task-012."""
from utils import calculate_values, format_result


class TestCalculateValues:
    def test_returns_sum_and_product(self):
        r = calculate_values(3, 4)
        assert r["sum"] == 7
        assert r["product"] == 12

    def test_has_correct_key_name(self):
        r = calculate_values(2, 5)
        # Should be 'calculated_value', not 'calulated_value'
        assert "calculated_value" in r
        assert r["calculated_value"] == 20


class TestFormatResult:
    def test_format(self):
        assert format_result({"a": 1, "b": 2}) == "a=1, b=2"
