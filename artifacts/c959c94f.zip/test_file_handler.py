import os
import pytest
import tempfile
from pathlib import Path
from file_handler import read_file, write_file, process_file


class TestFileHandler:
    def test_read_write_roundtrip(self):
        path = Path(tempfile.gettempdir()) / "test_devflow_normal.txt"
        try:
            write_file(str(path), "hello world")
            assert read_file(str(path)) == "hello world"
        finally:
            path.unlink(missing_ok=True)

    def test_unicode_filename(self):
        name = "test_chinese_filename.txt"
        path = Path(tempfile.gettempdir()) / name
        try:
            write_file(str(path), "unicode test")
            assert read_file(str(path)) == "unicode test"
        finally:
            path.unlink(missing_ok=True)

    def test_empty_file(self):
        path = Path(tempfile.gettempdir()) / "test_empty.txt"
        try:
            write_file(str(path), "")
            assert read_file(str(path)) == ""
        finally:
            path.unlink(missing_ok=True)

    def test_process_file(self):
        path = Path(tempfile.gettempdir()) / "test_process.txt"
        try:
            write_file(str(path), "hello")
            assert process_file(str(path)) == "HELLO"
        finally:
            path.unlink(missing_ok=True)
