"""Validators module. Provides validation functions extracted from user_service."""


def validate_username(username: str) -> None:
    """Raise ValueError if username is invalid."""
    if not username or len(username) < 3:
        raise ValueError("Username must be at least 3 characters")


def validate_email(email: str) -> None:
    """Raise ValueError if email is invalid."""
    if not email or "@" not in email:
        raise ValueError("Invalid email")


def validate_age(age: int) -> None:
    """Raise ValueError if age is negative or not an integer."""
    if not isinstance(age, int) or age < 0:
        raise ValueError("Age must be a non-negative integer")


