"""Tests for validators module."""
import pytest
from utils.validators import validate_username, validate_email, validate_age


class TestValidateUsername:
    def test_valid_username(self):
        validate_username("alice")  # should not raise

    def test_too_short(self):
        with pytest.raises(ValueError):
            validate_username("ab")

    def test_empty_string(self):
        with pytest.raises(ValueError):
            validate_username("")


class TestValidateEmail:
    def test_valid_email(self):
        validate_email("a@b.com")  # should not raise

    def test_missing_at(self):
        with pytest.raises(ValueError):
            validate_email("no-at-sign")

    def test_empty_string(self):
        with pytest.raises(ValueError):
            validate_email("")


class TestValidateAge:
    def test_valid_age(self):
        validate_age(25)  # should not raise
