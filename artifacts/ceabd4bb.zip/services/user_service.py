"""User service for DevFlow testing. Uses validators from utils.validators."""

from utils.validators import validate_username, validate_email, validate_age


class UserService:
    def __init__(self):
        self.users = {}

    def create(self, username, email, age):
        validate_username(username)
        validate_email(email)
        validate_age(age)
        self.users[username] = {"email": email, "age": age}
        return self.users[username]

    def update(self, username, email=None, age=None):
        if username not in self.users:
            raise KeyError(f"User {username} not found")
        if email is not None:
            validate_email(email)
            self.users[username]["email"] = email
        if age is not None:
            validate_age(age)
            self.users[username]["age"] = age
        return self.users[username]
